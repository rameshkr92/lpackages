<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Innoflame\Countries\Models\Country;
use Innoflame\Countries\Models\CountryTrans;
use Innoflame\Countries\Models\Area;
use Innoflame\Countries\Models\AreaTrans;
use Innoflame\Users\Models\User;
use Innoflame\Users\Models\UserRole;
use Innoflame\Media\Models\Media;
use Innoflame\Pages\Models\Page;
use Innoflame\Pages\Models\PageTrans;
use Innoflame\Settings\Controllers\SmsController;
use Auth;
use Lang;
use Innoflame\Media\Controllers\MediaApiController as MediaAPI;
use Innoflame\Users\Controllers\UsersApiController as API;
use Innoflame\Settings\Models\Setting;
use Config;
use Mail;
use Validator;

class CmsController extends Controller {

    public function __construct() {
        $this->api = new API;
    }

    /**
     * Overide Defualt Mail Settings.
     *
     * @return Response
     */
    public function setMailSettings() {
        Config::set('mail.driver', Setting::find(5)->value);
        Config::set('mail.host', Setting::find(6)->value);
        Config::set('mail.port', Setting::find(7)->value);
        Config::set('mail.username', Setting::find(8)->value);
        Config::set('mail.password', Setting::find(9)->value);
        Config::set('mail.from.address', Setting::find(10)->value);
        Config::set('mail.from.name', Setting::find(11)->value);
        Config::set('mail.encryption', Setting::find(12)->value);
    }

    /**
     * Show page
     *
     * @var view
     */
    public function showPage(Request $request, $page) {
//        $item = Page::findOrFail($page);
        $item = Page::where(array('page_url'=> $page, 'published'=>'1'))->first();
        if(count($item) == null){
            return redirect('/');
        }
        $trans = PageTrans::where('page_id', $item->id)->get()->keyBy('lang')->toArray();
//        $sections = Section::get();
        return view('website.pages.show', compact('item', 'trans'));
//        return view('website.pages.show');
    }

}
