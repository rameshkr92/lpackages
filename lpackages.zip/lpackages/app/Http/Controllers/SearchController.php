<?php
/**
 * Created by PhpStorm.
 * User: ramesh
 * Date: 30/5/17
 * Time: 6:41 PM
 */
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Innoflame\Activities\Models\Activity;
use Innoflame\Countries\Models\Country;
use Innoflame\Countries\Models\CountryTrans;
use Innoflame\Countries\Models\Area;
use Innoflame\Countries\Models\AreaTrans;
use Innoflame\Stores\Models\Store as webStore;
use Innoflame\Stores\Controllers\StoresApiController as StoreApi;
use Innoflame\Stores\Models\StoreTrans;
use Innoflame\Users\Models\User;
use Innoflame\Users\Models\UserRole;
use Innoflame\Settings\Controllers\SmsController;
use Innoflame\Ratings\Models\Rating;
use Innoflame\Ratings\Models\RatingTrans;
use Auth;
use Lang;
use Innoflame\Media\Controllers\MediaApiController as MediaAPI;
use Innoflame\Users\Controllers\UsersApiController as API;
use Innoflame\Settings\Models\Setting;
use Innoflame\Media\Models\Media;
use Config;
use Mail;

class SearchController extends Controller
{

    public function __construct()
    {
        $this->api = new API;
        $this->storeApi = new StoreApi;
    }

    /**
     * Search Result Page
     **/
    public function searchResult(Request $request){
        $request->request->add(['paginate' => 20]);
        $items = $this->storeApi->listItemsFrontSearch($request);
        if($_GET['store_name'] !="") {
            $storeData = webStore::where(array('id'=>$_GET['store_name']))->first();
            if(isset($storeData)) {
                if (isset(Auth::user()->id)) {
                    if (Auth::user()->id != $storeData->created_by) {
                        $storeData->search_count = $storeData->search_count + 1;
                        $storeData->save();
                    }
                }
                else {
                    $storeData->search_count = $storeData->search_count + 1;
                    $storeData->save();
                }
            }
        }

        $activities = Activity::where('active', 1)->get();
        $countries = Country::where('active', 1)->get();
        if(isset($request->country)){
            $areas = Area::where(array('country_id'=> $request->country,'active'=> 1))->get();
        }else{
            $areas = [];
        }
        $stores = webStore::where('active', 1)->get();
        return view('website.stores.search-result', compact('pages','activities', 'countries', 'areas', 'stores', 'banners','items'));
    }
    /**
     * Search Result Page
     **/
    public function storeDetail($id){
        $item = webStore::findOrFail($id);
        if (isset(Auth::user()->id)) {
            if(Auth::user()->id != $item->created_by){
//                $item->search_count = $item->search_count+1;
                $item->view_count = $item->view_count+1;
                $item->save();
            }
        }else{
//            $item->search_count = $item->search_count+1;
            $item->view_count = $item->view_count+1;
            $item->save();
        }
        $is_rated = "";
        if (isset(Auth::user()->id)) {
            $is_rated = Rating::where(array("store_id" => $id, "created_by" =>Auth::user()->id))->first();
        }
        $item = webStore::findOrFail($id);
        $gallery_count = \Innoflame\Stores\Models\StoreImage::where('store_id', $id)->get();
        if (isset($gallery_count)) {
            for ($i = 0; $i < count($gallery_count); $i++) {
                $media_id = ($item->images{$i}->options['media']['gallery_images']);
                $temp_image = Media::where('id', $media_id)->first();
                $gallery_images[$i]['media_id'] = $gallery_count[$i]->id;
                $gallery_images[$i]['file'] = $temp_image->file;
            }
        } else {
            $gallery_images = "";
        }
        $userData = Auth::user();
//        dd($item->images);
        return view('website.stores.store-detail', compact('item','gallery_images','is_rated','userData'));
    }

}
?>