<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Innoflame\Activities\Models\Activity;
use Innoflame\Countries\Models\Country;
use Innoflame\Countries\Models\CountryTrans;
use Innoflame\Countries\Models\Area;
use Innoflame\Countries\Models\AreaTrans;
use Innoflame\Ads\Models\Ad;
use Innoflame\Ads\Models\AdTrans;
use Innoflame\Users\Models\User;
use Innoflame\Users\Models\UserRole;
use Innoflame\Media\Models\Media;
use Innoflame\Stores\Models\Store;
use Innoflame\Stores\Models\StoreTrans;
use Innoflame\Stores\Models\StoreImage;
use Innoflame\Ratings\Models\Rating;
use Innoflame\Ratings\Models\RatingTrans;
use Auth;
use Lang;
use Innoflame\Stores\Controllers\StoresApiController as API;
use Innoflame\Settings\Models\Setting;
use Config;
use Mail;
use Validator;
//use Instagram;

class StoreController extends Controller {

    public function __construct() {
        $this->api = new API;
    }

    /**
     * Overide Defualt Mail Settings.
     *
     * @return Response
     */
    public function setMailSettings() {
        Config::set('mail.driver', Setting::find(5)->value);
        Config::set('mail.host', Setting::find(6)->value);
        Config::set('mail.port', Setting::find(7)->value);
        Config::set('mail.username', Setting::find(8)->value);
        Config::set('mail.password', Setting::find(9)->value);
        Config::set('mail.from.address', Setting::find(10)->value);
        Config::set('mail.from.name', Setting::find(11)->value);
        Config::set('mail.encryption', Setting::find(12)->value);
    }

    public function index(Request $request)
    {
//        echo "<a href='" . Instagram::getLoginUrl() . "'>Login with Instagram</a>";
        $author = Auth::user()->id;
        $request->request->add(['paginate' => 20]);
        $request->request->add(['author' => $author]);
        $items = $this->api->listItemsFront($request);
//        dd($items);
        return view('website.stores.index', compact('items'));
    }

    public function getInstagramData(){

    }
    /**
     * Store page
     *
     * @var view
     */
    public function addStore() {
        if (!isset(Auth::user()->id)) {
            \Session::flash('alert-class', 'alert-danger');
            \Session::flash('message', trans("Core::operations.signin_alert"));
            return redirect(Lang::getlocale() . "/" . 'home');
        }
        $activities = Activity::where('active', 1)->get();
        $countries = Country::where('active', 1)->get();
        $areas = Area::where('active', 1)->get();
        return view('website.stores.add-store', compact('activities', 'countries','areas'));
    }

    //save store page
    public function saveStore(Request $request)
    {
//        $this->validate($request, [
//            'name' => 'required|unique:stores_trans'
//        ]);
        if (isset(Auth::user()->id)) {
            $store = $this->api->createStore($request);
            $store = $store->getData();
            if (isset($store->errors)) {
                return back()->withInput()->withErrors($store->errors);
            }
            \Session::flash('alert-class', 'alert-success');
            \Session::flash('message', $store->message);
            return redirect(Lang::getlocale() . "/" . 'user/stores');
        }else{
            return redirect(Lang::getlocale() . "/" . 'home');
        }
    }

    /*
     * edit store
     */

    public function edit($id)
    {
        $item = Store::findOrFail($id);
        $activities = Activity::where('active', 1)->get();
        $trans = StoreTrans::where('store_id', $id)->get()->keyBy('lang')->toArray();
        $countries = Country::where('active', 1)->get();
        $areas = Area::where(array('country_id'=>$item->trans->country,'active'=> 1))->get();
        $edit = 1;

        $gallery_count = \Innoflame\Stores\Models\StoreImage::where('store_id', $id)->get();
        if (isset($gallery_count)) {
            for ($i = 0; $i < count($gallery_count); $i++) {
                $media_id = ($item->images{$i}->options['media']['gallery_images']);
                $temp_image = Media::where('id', $media_id)->first();
                $gallery_images[$i]['media_id'] = $gallery_count[$i]->id;
                $gallery_images[$i]['file'] = $temp_image->file;
            }
        } else {
            $gallery_images = "";
        }
        return view('website.stores.add-store', compact('item', 'trans', 'activities','countries','areas', 'edit','gallery_images'));
//        return view('Stores::stores.create-edit', compact('item', 'trans', 'activities','countries','areas', 'edit','gallery_images'));
    }

    /**
     *update store
     */
    public function update(Request $request, $id)
    {
        $update = $this->api->updateStore($request, '', $id);
        if($update == "Duplicate Entry Present")
            return back();
        $update = $update->getData();
        if(isset($update->errors)){
            return back()->withInput()->withErrors($update->errors);
        }
        \Session::flash('alert-class', 'alert-success');
        \Session::flash('message', $update->message);
        return redirect(Lang::getlocale() . "/" . 'user/stores');
    }

    /**
     *
     *
     * @param
     * @return
     */
    public function confirmDelete($id)
    {
        $item = Store::findOrFail($id);
        return view('Stores::stores.confirm-delete', compact('item'));
    }

    /**
     *
     *
     * @param
     * @return
     */
    public function bulkOperations(Request $request)
    {
        if($request->ids){
            $items = Store::whereIn('id', $request->ids)->get();
            if($items->count()){
                foreach ($items as $item) {
                    // Do something with your model by filter operation
                    if($request->operation && $request->operation === 'activate'){
                        $item->active = true;
                        $item->save();
                        \Session::flash('message', trans('Core::operations.activated_successfully'));
                    }elseif($request->operation && $request->operation === 'deactivate'){
                        $item->active = false;
                        $item->save();
                        \Session::flash('message', trans('Core::operations.deactivated_successfully'));
                    }

                }
            }

            \Session::flash('alert-class', 'alert-success');

        }else{
            \Session::flash('alert-class', 'alert-warning');
            \Session::flash('message', trans('Core::operations.nothing_selected'));
        }
        return back();
    }
    //rate now
    public function rateNow(Request $request){
        $store = Store::findOrFail($request->store_id);
        if (isset($store)) {
            $store->avg_rating = $store->avg_rating + $request->rating_val;
            $store->rating_count = $store->rating_count + 1;
            $store->save();
        }
        $rating = new Rating;
        if ($request->author) {
            $author = $request->author;
        } else {
            $author = Auth::user()->id;
        }

        $rating->created_by = $author;
        $rating->updated_by = $author;

        $rating->store_id = $request->store_id;

        $rating->active = false;
        if ($request->active) {
            $rating->active = true;
        }
        $rating->save();

        // Translation
        foreach ($request->language as $langCode) {
            $ratingTrans = new RatingTrans;
            $ratingTrans->rating_id = $rating->id;
            $ratingTrans->rating = $request->rating_val;
            $ratingTrans->comment = $request->store_comment;
            $ratingTrans->lang = $langCode;
            $ratingTrans->save();
        }
        \Session::flash('alert-class', 'alert-success');
        \Session::flash('message', "Thank you for your rating.");
        return redirect(Lang::getlocale() . '/search-result/'.$request->store_id.'/view');
    }

}
