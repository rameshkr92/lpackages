<?php

namespace App\Http\Middleware;

use Closure;

// Custom innoflame
class ApiMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(\Request::segment(3) !== config('innoflame.api_key')){
            $response = [
                    'status' => 0,
                    'message' => 'not authorized'
            ];
            return \Response($response);
        }
        
        return $next($request);
    }
}
