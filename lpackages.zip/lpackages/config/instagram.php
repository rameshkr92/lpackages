<?php

return [

	'client_id' 	=> env('c170fbf2840444428061fca2288023e5'),
	'client_secret' => env(' 375594a07d204e25ae634b63da0eba79'),
	'redirect_uri' 	=> env('INSTAGRAM_REDIRECT_URI'),
//	'redirect_uri' 	=> env(url('/en/user/stores/instagram')),
	'scopes'		=> 'basic public_content'

];