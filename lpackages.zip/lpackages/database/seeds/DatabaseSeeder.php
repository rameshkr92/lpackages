<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//    	$this->call(Innoflame\Users\Seeds\RolesTableSeeder::class);
//        $this->call(Innoflame\Users\Seeds\UsersTableSeeder::class);
//        $this->call(Innoflame\Countries\Seeds\CountriesTableSeeder::class);
//        $this->call(Innoflame\Settings\Seeds\SettingsTableSeeder::class);
        $this->call(RolesTableSeeder::class);
        $this->call(UsersTableSeeder::class);
        $this->call(CountriesTableSeeder::class);
        $this->call(SettingsTableSeeder::class);
    }
}
