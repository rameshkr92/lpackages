<?php

namespace Innoflame\Contactus\Models;

use Illuminate\Database\Eloquent\Model;
use Lang;

class ContactusReplyTrans extends Model
{
    protected $table = 'contact_request_replies_trans';
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */

}
