<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
$locale = \Request::segment(1);

Route::group(['middleware' => ['web'], 'prefix' => 'admin'], function() {
	Route::get('login', 'Innoflame\Core\Controllers\AdminLoginController@getAdmin');
	Route::post('login', 'Innoflame\Core\Controllers\AdminLoginController@postAdmin');
	Route::get('logout', 'Innoflame\Core\Controllers\AdminLoginController@getAdminLogout');
});

Route::group(['middleware' => ['web'], 'prefix' => $locale.'/admin'], function() {
	Route::get('login', 'Innoflame\Core\Controllers\AdminLoginController@getAdmin');
	Route::post('login', 'Innoflame\Core\Controllers\AdminLoginController@postAdmin');
	Route::get('logout', 'Innoflame\Core\Controllers\AdminLoginController@getAdminLogout');
});

$action = 'Innoflame\Core\Controllers\DashboardController@index';
if(Config::has('innoflame.dashboard_function') && !empty(config('innoflame.dashboard_function'))){
	$action = config('innoflame.dashboard_function');
}

Route::group(['middleware' => ['web' ,'admin'], 'prefix' => $locale], function() use($action) {
	Route::get('admin', $action);
});

Route::group(['middleware' => ['web' ,'admin']], function() use($action) {
    
	Route::get('admin', $action);

        
        
});

Route::group(['middleware' => ['web' ,'admin'], 'prefix' => $locale.'/admin'], function() {
	Route::POST('delete-item', 'Innoflame\Core\Controllers\OperationsController@delete');
	Route::POST('bulk-delete-items', 'Innoflame\Core\Controllers\OperationsController@bulkDelete');
});