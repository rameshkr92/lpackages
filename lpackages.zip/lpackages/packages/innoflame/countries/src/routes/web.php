<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
$locale = \Request::segment(1);

Route::group(['middleware' => ['web' ,'admin'], 'prefix' => $locale.'/admin'], function() {
	# Countries
	Route::GET('countries', 'Innoflame\Countries\Controllers\CountriesController@index');
	Route::GET('countries/create', 'Innoflame\Countries\Controllers\CountriesController@create');
	Route::POST('countries', 'Innoflame\Countries\Controllers\CountriesController@store');
	Route::GET('countries/{id}/edit', 'Innoflame\Countries\Controllers\CountriesController@edit');
	Route::PATCH('countries/{id}', 'Innoflame\Countries\Controllers\CountriesController@update');
	Route::POST('countries/bulk-operations', 'Innoflame\Countries\Controllers\CountriesController@bulkOperations');

	# ِAreas
	Route::GET('countries-areas', 'Innoflame\Countries\Controllers\AreasController@index');
	Route::GET('countries-areas/create', 'Innoflame\Countries\Controllers\AreasController@create');
	Route::POST('countries-areas', 'Innoflame\Countries\Controllers\AreasController@store');
	Route::GET('countries-areas/{id}/edit', 'Innoflame\Countries\Controllers\AreasController@edit');
	Route::PATCH('countries-areas/{id}', 'Innoflame\Countries\Controllers\AreasController@update');
	Route::POST('countries-areas/bulk-operations', 'Innoflame\Countries\Controllers\AreasController@bulkOperations');
});