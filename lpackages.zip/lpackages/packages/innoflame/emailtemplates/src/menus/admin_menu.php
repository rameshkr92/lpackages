<?php
$adminMenu[8] = [
        'icon' => 'emailtemplates',
        'list_head' => [
                'name' => trans('Emailtemplates::emailtemplate.emailtemplates'),
                'link' => '/'.App::getLocale().'/admin/emailtemplates',
        ]
];

?>