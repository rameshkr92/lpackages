<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
$locale = \Request::segment(1);

Route::group(['middleware' => ['web' ,'admin'], 'prefix' => $locale.'/admin'], function() {
    //Pages
    Route::GET('pages', 'Innoflame\Pages\Controllers\PagesController@index');
    Route::GET('pages/dynamic', 'Innoflame\Pages\Controllers\PagesController@dynamic');
    Route::GET('pages/create', 'Innoflame\Pages\Controllers\PagesController@create');
    Route::POST('pages', 'Innoflame\Pages\Controllers\PagesController@store');
    Route::GET('pages/{id}/edit', 'Innoflame\Pages\Controllers\PagesController@edit');
    Route::PATCH('pages/{id}', 'Innoflame\Pages\Controllers\PagesController@update');
    Route::POST('pages/bulk-operations', 'Innoflame\Pages\Controllers\PagesController@bulkOperations');
});