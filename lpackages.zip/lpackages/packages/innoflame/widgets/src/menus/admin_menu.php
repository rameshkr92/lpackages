<?php
//$adminMenu[15] = [
//        'icon' => 'table',
//        'list_head' => [
//                'name' => trans('Widgets::widgets.ads'),
//                'link' => '/'.App::getLocale().'/admin/widgets',
//        ],
//        'list_tree'=> [
//                0 => [
//                    'name' => trans('Widgets::widgets.all_ads'),
//                    'link' => '/'.App::getLocale().'/admin/widgets',
//                ],
//                1 => [
//                    'name' => trans('Widgets::widgets.create').' '.trans('Widgets::widgets.ad'),
//                    'link' => '/'.App::getLocale().'/admin/widgets/create',
//                ]
//        ]
//];