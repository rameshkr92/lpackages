<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
$locale = \Request::segment(1);

Route::group(['middleware' => ['web' ,'admin'], 'prefix' => $locale.'/admin'], function() {
	# Ads
	Route::GET('widgets', 'Innoflame\Widgets\Controllers\WidgetController@index');
	Route::GET('widgets/create', 'Innoflame\Widgets\Controllers\WidgetController@create');
	Route::POST('widgets', 'Innoflame\Widgets\Controllers\WidgetController@store');
	Route::GET('widgets/{id}/edit', 'Innoflame\Widgets\Controllers\WidgetController@edit');
	Route::PATCH('widgets/{id}', 'Innoflame\Widgets\Controllers\WidgetController@update');
	Route::POST('widgets/bulk-operations', 'Innoflame\Widgets\Controllers\WidgetController@bulkOperations');

});