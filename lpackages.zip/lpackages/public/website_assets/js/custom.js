jQuery(document).ready(function(){
/********* Sticky Header ************/	
jQuery(window).scroll(function(){
	var sticky = jQuery('body'),
	    scroll = jQuery(window).scrollTop();
		
	if(scroll >= 200) sticky.addClass('sticky-header');
	else sticky.removeClass('sticky-header');
});

/********* Mob mneu ************/	
 jQuery(".mob-menu").click(function(){
  jQuery("body").toggleClass("open-mob-menu");	 
});

/********* Cat list ************/	
jQuery(".all-cat-blok").click(function(){
  jQuery("body").toggleClass("open-cat-blk-list");
});

/********* Db Left Menu ************/	
jQuery(".nav-icon").click(function(){
  jQuery("body").toggleClass("hide-left-menu");
});

/********* Db Left Menu inner toggle ************/	
jQuery(".quik-acc").click(function(){
  jQuery(".quik-acc-lis").slideToggle('slow');
});

//Slider 	
jQuery('.fix-bac-slider').owlCarousel({
	    loop:true,
		items:1,
		nav:false,
		dots:false,
		autoplay:true,
		autoplayTimeout:5000,
		smartSpeed:2500,
		navText: false,
		animateOut : 'fadeOut',
		animateIn : 'fadeIn',
		
});

$("#lightgallery").lightGallery();

});
$('#html5-videos').lightGallery();

 $(window).bind("load", function() {
       var footer = $(".footer-container");
        var pos = footer.position();
        var height = $(window).height();
        height = height - pos.top;
        height = height - footer.height();
        if (height > 0) {
       footer.css({'margin-top' : height+'px'});
      }
    });