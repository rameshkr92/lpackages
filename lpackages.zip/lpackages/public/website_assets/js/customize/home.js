var page = 1;
var page1 = 1;
var page2 = 1;
$(document).ready(function(){
    // call function on #btn-more
    $(document).on('click','#btn-more-latest-store',function(){
        page++;
        loadMoreLatestStores(page);
    });
    $(document).on('click','#btn-more-visited-store',function(){
        page1++;
        loadMoreVisitedStores(page1);
    });
    $(document).on('click','#btn-more-rated-store',function(){
        page2++;
        loadMoreRatedStores(page2);
    });
});
function loadMoreLatestStores(page){
    $.ajax({
        url: '?page=' + page,
        type: "get",
        data:{
            'store_type':'latest'
        },
        beforeSend: function()
        {
            $('.ajax-load').show();
        }
    }).done(function(data){
        // console.log(data.html);
        // alert(data.html);
        if(data.html == ""){
            $('#btn-latest-seemore').fadeOut();
            // $('.ajax-load').html("No more records found");
            return;
        }
        $('.ajax-load').hide();
        $("#latest-store-data").append(data.html);
    }).fail(function(jqXHR, ajaxOptions, thrownError){
        alert('server not responding...');
    });
}
//load most visited stores
function loadMoreVisitedStores(page1){
    $.ajax({
        url: '?page=' + page1,
        type: "get",
        data:{
            'store_type':'visited'
        },
        beforeSend: function()
        {
            $('.ajax-load').show();
        }
    }).done(function(data){
        if(data.html == ""){
            $('#btn-visited-seemore').fadeOut();
            // $('.ajax-load').html("No more records found");
            return;
        }
        $('.ajax-load').hide();
        $("#visited-store-data").append(data.html);
    }).fail(function(jqXHR, ajaxOptions, thrownError){
        alert('server not responding...');
    });
}
//load most rated stores
function loadMoreRatedStores(page2){
    $.ajax({
        url: '?page=' + page2,
        type: "get",
        data:{
            'store_type':'rated'
        },
        beforeSend: function()
        {
            $('.ajax-load').show();
        }
    }).done(function(data){
        if(data.html == ""){
            $('#btn-rated-seemore').fadeOut();
            // $('.ajax-load').html("No more records found");
            return;
        }
        $('.ajax-load').hide();
        $("#rated-store-data").append(data.html);
    }).fail(function(jqXHR, ajaxOptions, thrownError){
        alert('server not responding...');
    });
}