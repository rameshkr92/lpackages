// Wait for the DOM to be ready
$(function() {
    $.validator.setDefaults({
        debug: true,
        errorElement: "div",
        errorClass: "text-danger",
        highlight: function (element) {
            $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
        },
        unhighlight: function (element) {
            $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
        },
        errorPlacement: function (error, element) {
            if (element.parent('.input-group').length || element.prop('type') === 'checkbox' || element.prop('type') === 'radio') {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        }
    });
    //forgot password
    $("#frm_store_rating").validate({
        rules: {
            store_comment: {
                required: true,
                minlength: 2
            },
            rating_val: {
                required: true
            }
        },
        messages: {
            store_comment: {
                required: "Please provide your comment here.",
                minlength: "Please enter at least {0} characters."
            },
            rating_val: {
                required: "Please provide your rating."
            }
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
});