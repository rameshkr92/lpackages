// Wait for the DOM to be ready
$(function() {
    $.validator.setDefaults({
        debug: true,
        errorElement: "div",
        errorClass: "text-danger",
        highlight: function (element) {
            $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
        },
        unhighlight: function (element) {
            $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
        },
        errorPlacement: function (error, element) {
            if (element.parent('.input-group').length || element.prop('type') === 'checkbox' || element.prop('type') === 'radio') {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        }
    });

    $.validator.addMethod("username_regex", function(value, element) {
        return this.optional(element) || /^[a-z0-9\.\-_]{3,30}$/i.test(value);
    }, "Please choise a username with only a-z 0-9.");

    jQuery.validator.addMethod(
        "full_name",
        function(value, element) {
            // return this.optional(element) || /^[A-Za-z]+ [A-Za-z]+(?: [A-Za-z]+)+$/i.test(value);
            return this.optional(element) || /^[A-Za-z]+(?: [A-Za-z]+)+$/i.test(value);
        },
        "Please Include First and Last Name.)"
    );
    // create a custom phone number rule called 'intlTelNumber'
    jQuery.validator.addMethod("intlTelNumber", function(value, element) {
        return this.optional(element) || $(element).intlTelInput("isValidNumber");
    }, "Please enter a valid International Phone Number");
    // Initialize form validation on the registration form.
    // It has the name attribute "registration"
    $("#frm_registration").validate({
        rules:{
            name:{
                required: true,
                full_name: true
            },
            email:{
                required: true,
                email: true,
                remote: {
                    url: $("#base_path").val()+'check-email-vailability',
                    type: 'GET',
                    delay: 1000,
                    message: 'The email is not available.'
                }
            },
            phone:{
                required: true,
                intlTelNumber:true
            },
            password:{
                required: true,
                minlength: 6
            },
            password_confirmation:{
                required: true,
                minlength: 6,
                equalTo: '#password'
            }
        },
        messages:{
            name:{
                required: "The name field is mandatory!",
                full_name: "Please Include First and Last Name."
            },
            email:{
                required: "The Email is required!",
                email: "Please enter a valid email address!",
                remote: "The email is already in use by another user!"
            },
            phone:{
                required: "The phone number is required!"
            },
            password: {
                required: "Please enter new password.",
                minlength: "Please enter at least {0} characters.",
                remote: "Choose a password you haven't previously used with this account."
            },
            password_confirmation: {
                required: "Please enter confirm password.",
                minlength: "Please enter at least {0} characters.",
                equalTo: "New password doesn't match with confirm password."
            }
        },
        // in the "action" attribute of the form when valid
        submitHandler: function(form) {
            form.submit();
        }
    });
    //login
    $("#frm_login").validate({
        // Specify validation rules
        rules: {
            user_email: {
                required: true,
                email: true
            },
            user_password: {
                required: true,
                minlength: 6
            }
        },
        // Specify validation error messages
        messages: {
            user_email: {
                required: "Please enter your email address",
                email: "Please enter a valid email address"
            },
            user_password: {
                required: "Please provide a password",
                minlength: "Your password must be at least 6 characters long"
            }
        },
        // Make sure the form is submitted to the destination defined
        // in the "action" attribute of the form when valid
        submitHandler: function(form) {
            form.submit();
        }
    });
    //forgot password
    $("#frm_forgot_password").validate({
        rules: {
            reset_email: {
                required: true,
                email: true
            }
        },
        messages: {
            reset_email: {
                required: "Please enter your email address",
                email: "Please enter a valid email address"
            }
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
    //reset password
    $("#reset_password").validate({
        rules: {
            password:{
                required: true,
                minlength: 6
            },
            password_confirmation:{
                required: true,
                minlength: 6,
                equalTo: '#password'
            }
        },
        messages: {
            password: {
                required: "Please enter new password.",
                minlength: "Please enter at least {0} characters.",
                remote: "Choose a password you haven't previously used with this account."
            },
            password_confirmation: {
                required: "Please enter confirm password.",
                minlength: "Please enter at least {0} characters.",
                equalTo: "New password doesn't match with confirm password."
            }
        },
        submitHandler: function(form) {
            form.submit();
        }
    });
//update profile
    $("#frm_update_profile").validate({
        rules:{
            name:{
                required: true,
                full_name: true
            },
            phone:{
                required: true/*,
                intlTelNumber:true*/
            },
            country:{
                required: true
            },
            area:{
                required: true
            }
        },
        messages:{
            name:{
                required: "The name field is mandatory!",
                full_name: "Please Include First and Last Name."
            },
            phone:{
                required: "The phone number is required!"
            },
            country:{
                required: "Country field is required.",
            },
            area:{
                required: "Area field is required.",
            }
        },
        // in the "action" attribute of the form when valid
        submitHandler: function(form) {
            form.submit();
        }
    });
});