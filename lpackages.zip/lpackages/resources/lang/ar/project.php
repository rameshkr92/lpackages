<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Control panel trans
    |--------------------------------------------------------------------------
    |
    |
    */
    'home_search_head' => 'أكثر من 6000 حسابات لأكثر من 30 منطقة حول العالم',
    'latest_added_store' => 'أحدث المتاجر المضافة',
    'best_rated_stores' => 'أفضل المتاجر تقييما',
    'most_visited_stores' => 'الأكثر زيارة المتاجر',
    'see_more' => 'شاهد المزيد',
    'search' => 'بحث',
    'registration_successfull1' => "التسجيل ناجح! تم إرسال رسالة تأكيد إلكترونية إلى ",
    'registration_successfull2' => ". إذا لم تتلق رسالة التأكيد الإلكترونية هذه في صندوق البريد الإلكتروني في غضون بضع دقائق، فيرجى التحقق من مجلد الرسائل غير المرغوب فيها في بريدك الإلكتروني.",

    'thankyou' => 'أشكركم على الاتصال بنا',
    'dear_admin' => 'عزيزنا المستخدم المسؤول اتصل بك.',
    'phone_number_must_between' => 'الرجاء إدخال رقم الهاتف الصحيح 9665XXXXXXXX، 05XXXXXXXX، 5XXXXXXXX',
    'you_have_changed_your_email' => 'عزيزي المستخدم قمت بتغيير البريد الإلكتروني الخاص بك يرجى النقر على الرابط أدناه لتفعيل الحساب.',
    'email_change_success' => 'تم تغيير بريدك الإلكتروني بنجاح',
    'new_enter_phone' => 'أدخل رقم الهاتف الجديد',
    'phone_changed_success' => 'تم تغيير رقم الهاتف بنجاح',
    'enter_correct_otp' => 'أدخل كلمة مرور صحيحة مرة واحدة',
    'old_otp_sent' => 'لقد تم إرسال رمز تفعيل على الهاتف القديم ',
    'new_otp_sent' => 'تم إرسال رمز التفعيل إلى هاتفك الجديد',
    'enter_correct_phone' => 'الرجاء إدخال رقم الهاتف الصحيح',
    'activate_my_account' => 'تنشيط حسابي',
    'email_change' => 'تغيير البريد الإلكتروني',
    'we_have_email_change' => 'لقد أرسلنا لك البريد الإلكتروني يرجى التحقق من البريد الوارد الخاص بك لتفعيل الحساب',
    'dear_user_change_my_password' => 'عزيزي المستخدم يرجى النقر على الرابط أدناه لإعادة تعيين كلمة المرور الخاصة بك',
    'change_my_password' => 'تغيير كلمة المرور الخاصة بي',
    'project_name' => 'InstaFilter',
    'sowfware_category' => 'موقع إلكتروني',
    'specialty' => 'إعلانات مبوبة',
    'production_date' => '20-07-2017',
    'registerd_successfuly_and_sms_sent' => 'حسابك غير مفعل ، تم إرسال رسالة التفعيل على جوالك',
    'activation_code_msg' => 'رمز تفعيل حساب موقع سلعة: ',
    'account_confirmed_successfully' => 'تم تفعيل حسابك بنجاح',
    'logout_successfully' => 'تم تسجيل الخروج بنجاح',
    'login_successfully' => 'مرحبا بك مجددا',
    'invalid_login_data' => 'بيانات تسجيل الدخول غير صحيحة، أو أن حسابك غير نشط.',
    'reset_password' => 'تغيير كلمة المرور',
    'reset_your_password' => 'إعادة تعيين كلمة المرور',
    'check_your_email' => 'يرجى التحقق من عنوان البريد الإلكتروني الخاص بك وانقر على الرابط المرسلة لك. إذا لم تتمكن من العثور على البريد في البريد الوارد، فحدد مربع الانتقال / الرسائل غير المرغوب فيها',
    'user_dosnt_match' => 'مستخدم غير موجود',
    'phone_or_email_shouldnt_empty' => 'يجب إدخال عنوان بريدك الإلكتروني لإعادة تعيين كلمة المرور.',
    'confirmation_code_sent_successfully' => 'تم إرسال كود التحقق بنجاح',
    'password_reset_success' => 'تم تحديث كلمة المرور بنجاح',
    'wrong_url' => 'رابط غير صحيح',
    'confirmation_link_invalid' => 'انتهت صلاحية رابط التنشيط.',

    'confirmation_code_doesnt_match' => 'رمز التفعيل المدخل غير صحيح ',
    'contactus_success' => 'شكرا لإتصالك بنا! نحن سوف نعود اليكم في وقت قريب.',
    'create_your_account' => 'أنشئ حسابك',
    'already_have_an_account' => 'هل لديك حساب بالفعل؟',
    'click_here' => 'انقر هنا',
    'to_login' => 'لتسجيل الدخول',
    'forgot_password' => 'نسيت رقمك السري؟',
    'forgot_password_sub_heading' => "سنرسل إليك رسالة إلكترونية تتضمن إرشادات لاختيار كلمة مرور جديدة.",
    'submit' => 'عرض',
    'password' => 'كلمه السر',
    'confirm_password' => 'تأكيد كلمة المرور',

];
