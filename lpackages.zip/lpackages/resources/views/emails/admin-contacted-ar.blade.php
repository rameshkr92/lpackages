<p>مرحبا {{$userName}},</p>

<p>{{$message}},</p>

<p>مع تحياتي,</p>

<p>InstaFilter</p>
