<p>Hi {{ $userName }},</p>

<p>{{ $messageContent }},</p>

<p>Regards,</p>

<p>InstaFilter</p>
