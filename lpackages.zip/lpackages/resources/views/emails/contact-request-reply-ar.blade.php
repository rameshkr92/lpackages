<html><body style="font-family:Arial, Helvetica, sans-serif;font-size:12px;">{!! $MESSAGE !!}
    
    
            <p>
              <br />
    <br />
    <br />
   <a href="{{url('/')}}"> انتقل إلى موقع الويب</a>
        </p>
    </body></html>