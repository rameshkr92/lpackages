<p>مرحبا,</p>

<p><br />
{{$userName}} اتصل بك على {{$contactDate}},</p>

<p>مع تحياتي,</p>

<p>InstaFilter</p>
