<p>Hi,</p>

<p><br />
{{$userName}} has contacted you on {{$contactDate}},</p>

<p>Regards,</p>

<p>InstaFilter</p>
