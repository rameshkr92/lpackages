<html>
    <head>
        <title>
            Denied
        </title>
    </head>
    
</html>
<body>
    <div class="container-fluid">
        <img src="{{ url('/') }}/images/access.jpg" height="100%" width="100%">
</div>
    </body>
    </html>
