<html>
    <head>
        <title>
            Denied
        </title>
    </head>
    
</html>
<body>
    <div class="container-fluid">
        <img src="{{ url('/') }}/images/page-not-found.gif" height="100%" width="100%">
</div>
    </body>
    </html>
