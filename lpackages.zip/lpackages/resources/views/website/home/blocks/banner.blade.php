<div class="fix-bac-slider owl-carousel owl-theme" >
    <!-- Wrapper for slides -->
    @if(isset($banners) && count($banners) > 0)
        @foreach($banners as $key => $item)
            @if($key == 0)
                <div class="item active">
                    <a href="{{ $item->url  }}" target="_blank">
                        <img src="{{url('/uploads/banners/thumbs')}}/{{ $item->trans->banner_img }}" alt="Second slide">
                    </a>
                </div>
            @else
                <div class="item">
                    <a href="{{ $item->url  }}" target="_blank"><img src="{{url('/uploads/banners/thumbs')}}/{{ $item->trans->banner_img }}" alt="Second slide"></a>
                </div>
            @endif
        @endforeach
    @else
        <div class="item ">
            <img src="{{url('/')}}/website_assets/images/erik-lundqvist-221875.jpg">
        </div>
        <div class="item">
            <img src="{{url('/')}}/website_assets/images/gianluca-cosetta-3412.jpg">
        </div>
        <div class="item">
            <img src="{{url('/')}}/website_assets/images/brett-reeves-202718.jpg">
        </div>
    @endif
</div>