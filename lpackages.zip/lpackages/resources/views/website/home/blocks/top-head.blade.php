<div class="login-blok-head animate">
    @if(Auth::guest())
    <a href="javascript:void(0)" data-toggle="modal" data-target="#myModallogin"> <span class="animate">Login / Register</span> <i class="fa fa-user animate"></i> </a>
    @else
        <a href="{{ action('WebsiteController@dashboard', [Auth::user()->id, Auth::user()->phone, 'confirm_account']) }}" > <span class="animate">{{Auth::user()->name}}</span> <i class="fa fa-user animate"></i> </a>
    @endif
</div>
@if(Request::segment(2) == "search-result")
    <div class="logoedit">
    <a href="{{url('/'.Lang::getLocale().'/home')}}"> <img src="{{url('/')}}/website_assets/images/Logo.png" width="20%" /></a>
    </div>
@else
    <div class="logo animate"><a href="{{url('/'.Lang::getLocale().'/home')}}"> <img src="{{url('/')}}/website_assets/images/Logo.png" width="37%" /> </a></div>
@endif