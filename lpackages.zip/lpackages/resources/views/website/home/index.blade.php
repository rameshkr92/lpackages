@extends('website.master')
@section('content')
    <style type="text/css">
        .ajax-load {
            {{--background:url({{ asset('website_assets/img/load-more.gif') }}) no-repeat center center;--}}
            background:url({{ asset('website_assets/img/load-more.gif') }}) no-repeat center center #fff;
            opacity: 1;
            height: 100px;
            width: 100px;
            position: fixed;
            left: 50%;
            top: 50%;
            margin: -25px 0 0 -25px;
            z-index: 1000;
        }
    </style>
    {{--<div class="ajax-load"></div>--}}
    <div class="container">
        @include('website.regions.header')
        @include('website.home.blocks.banner')
        @include('website.home.blocks.top-head')
        <div class="middle-blk">
            <div class="offercont">
                <h2 class="offertitle">{{trans('project.home_search_head')}}</h2>
            </div>
            @include('website.home.blocks.home-filter')
            <div class="shop-listing">
                <div class="lastadded ">
                    <div class="comm-head">
                        <h2>{{trans('project.latest_added_store')}}</h2>
                    </div>
                    <div class="row form-group" id="latest-store-data">
                        @include('website.home.blocks.latest-stores')
                    </div>
                    <div id="btn-latest-seemore" class="seemore">
                        <a id="btn-more-latest-store" href="javascript:void(0);" class="btn btn-warning">{{trans('project.see_more')}}</a>
                    </div>
                </div>
                <!--         ads google-->
                <div class="googleads form-group">
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-xs-12 jquery-script-ads">
                            @if(isset($ads1))
                                {!! $ads1->scripts !!}
                            @else
                                <img src="{{url('/')}}/website_assets/images/ads3.jpg" width="100%">
                            @endif
                        </div>
                        <div class="col-sm-6 col-md-6 col-xs-12 jquery-script-ads">
                            @if(isset($ads2))
                                {!! $ads2->scripts !!}
                            @else
                                <img src="{{url('/')}}/website_assets/images/ads3.jpg" width="100%">
                            @endif
                        </div>
                    </div>
                </div>
                {{--Most visited stores--}}
                <div class=" mostseen ">
                    <div class="comm-head">
                        <h2>{{trans('project.most_visited_stores')}}</h2>
                    </div>
                    <div class="row form-group" id="visited-store-data">
                        @include('website.home.blocks.visited-stores')
                    </div>
                    <div id="btn-visited-seemore" class="seemore">
                        <button id="btn-more-visited-store" type="button" class="btn btn-warning">{{trans('project.see_more')}}</button>
                    </div>
                </div>
                <!--         ads google-->
                <div class="googleads form-group">
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-xs-12 jquery-script-ads">
                            @if(isset($ads3))
                                {!! $ads3->scripts !!}
                            @else
                                <img src="{{url('/')}}/website_assets/images/ads3.jpg" width="100%">
                            @endif
                        </div>
                        <div class="col-sm-6 col-md-6 col-xs-12 jquery-script-ads">
                            @if(isset($ads4))
                                {!! $ads4->scripts !!}
                            @else
                                <img src="{{url('/')}}/website_assets/images/ads3.jpg" width="100%">
                            @endif
                        </div>
                    </div>
                </div>
                <div class=" mostseen ">
                    <div class="comm-head">
                        <h2>{{trans('project.best_rated_stores')}}</h2>
                    </div>
                    <div class="row form-group" id="rated-store-data">
                        @include('website.home.blocks.rated-stores')
                    </div>
                    <div id="btn-rated-seemore" class="seemore">
                        <button id="btn-more-rated-store" type="button" class="btn btn-warning">{{trans('project.see_more')}}</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer')
    <script src="{{ asset('website_assets/js/customize/home.js') }}" type="text/javascript"></script>
@endsection