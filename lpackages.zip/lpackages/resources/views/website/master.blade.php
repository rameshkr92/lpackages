<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{ \Innoflame\Settings\Models\Setting::find(1)->value }}</title>
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" href="{{ asset('website_assets/images/fav.png') }}">
    <!---------------------------------- Css Files Link ---------------------------------->
    <link href="{{ asset('website_assets/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('website_assets/css/owl.carousel.min.css') }}" rel="stylesheet">
    <link href="{{ asset('website_assets/css/lightbox.css') }}" rel="stylesheet">
    <link href="{{ asset('website_assets/css/lightgallery.css') }}" rel="stylesheet">
    <link href="{{ asset('website_assets/css/owl.theme.default.min.css') }}" rel="stylesheet">
    <link href="{{ asset('website_assets/css/jquery.mCustomScrollbar.css') }}" rel="stylesheet">
    <link href="{{ asset('website_assets/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('website_assets/css/animated.css') }}" rel="stylesheet">
    @if(Lang::getLocale() == 'ar')
        <link href="{{ asset('website_assets/css/rtl.css') }}" rel="stylesheet">
    @else
        <link href="{{ asset('website_assets/css/style.css') }}" rel="stylesheet">
    @endif
    <link href="{{ asset('website_assets/css/responsive.css') }}" rel="stylesheet">
    {{--<script src="{{ asset('website_assets/js/jquery.min.js') }}" type="text/javascript"></script>--}}
    <script src="{{ asset('admin_assets/js/jquery-1.11.1.min.js') }}"></script>
    @yield('header')
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script>
        (adsbygoogle = window.adsbygoogle || []).push({
            google_ad_client: "ca-pub-4149154288627830",
            enable_page_level_ads: true
        });
    </script>
    @include('website.blocks.message')
</head>
<body>
    @yield('content')
@if(Request::segment(2) != "user")
    @include('website.regions.footer')
@endif
<!---------------------------------- JS Files Link ---------------------------------->
{{--<script src="{{ asset('website_assets/js/jquery.js') }}" type="text/javascript"></script>--}}
    <script src="{{ asset('admin_assets/js/jquery-ui.js') }}"></script>
<script src="{{ asset('website_assets/js/bootstrap.min.js') }}" type="text/javascript"></script>
{{--<script src="{{ asset('website_assets/js/lightbox.min.js') }}" type="text/javascript"></script>--}}
<script src="{{ asset('website_assets/js/owl.carousel.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('website_assets/js/jquery.mCustomScrollbar.concat.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('website_assets/js/wow.js') }}" type="text/javascript"></script>
<script src="{{ asset('website_assets/js/script.js') }}" type="text/javascript"></script>
<script src="{{ asset('website_assets/js/lightgallery.js') }}" type="text/javascript"></script>
<script src="{{ asset('website_assets/js/lg-autoplay.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('website_assets/js/lg-fullscreen.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('website_assets/js/lg-video.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('website_assets/js/custom.js') }}" type="text/javascript"></script>
<script type="text/javascript">
    var javascript_site_path = "{{url('/')}}" + "/";
    // Load country areas
    $('#country1').on("change", function() {
        var selectedValues = $('#country1').val();
        $.ajax({
            type: "POST",
            url: javascript_site_path + "get-selected-cities",
            data: {
                selectedValues: selectedValues
            },
            success: function(data) {
                $("#area1").html(data);
                $('#area1').selectpicker('refresh');
            }
        });
    });
</script>
<script type="text/javascript">
    // Load country areas
    $('#country').on("change", function() {
        var selectedValues = $('#country').val();
        $.ajax({
            type: "POST",
            url: javascript_site_path + "get-selected-cities",
            data: {
                selectedValues: selectedValues
            },
            success: function(data) {
                $("#area").html(data);
                $('#area').selectpicker('refresh');


            }
        });
    });
</script>
@yield('footer')
</body>
</html>