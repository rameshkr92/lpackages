@extends('website.master')
@section('content')
    <div class="cms-pages faq-page">
        <div class="container">
            @include('website.home.blocks.top-head')
            <div class="login">
                <div class="main-blog-sec">
                    <div class="about-section">
                        <div class="	">
                            <div class="comm-head cms-head">{{$item->trans->title}}</div>
                            <p>
                                {!! $item->trans->body !!}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer')

@stop