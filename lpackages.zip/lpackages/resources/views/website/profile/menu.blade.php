<style>
    .hideDiv {
        display: none;
    }
</style>
<nav class="navbar navbar-default sidebar" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-sidebar-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <div class="collapse navbar-collapse" id="bs-sidebar-navbar-collapse-1">
            <ul id="nav-tabs-wrapper1" class="nav nav-tabs nav-pills nav-stacked well">
                <li class="active" id='parent_one'><a href="#vtab1" data-toggle="tab">حسابى</a></li>
                <li onclick="showNext()" id='parent_show'><a href="javascript:void(0)" data-toggle="tab">   إضافة إعلان  </a>
                 </li>
                <div class="hideDiv" id="show">
                    <li>
                        <a href="{{ url('/')."/".Lang::getLocale()."/add-post" }}">
                            إضافة إعلان
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('/')."/".Lang::getLocale()."/add-post-cars" }}">
                            إضافة إعلان في قسم السيارات
                        </a>
                    </li>
                </div>  
                   
            
                <li><a href="#vtab3" data-toggle="tab">اعلاناتى</a></li>
                <li><a href="#vtab4" data-toggle="tab">التعليقات </a></li>
                <li><a href="#vtab5" data-toggle="tab">المفضلة</a></li>
                {{--<li><a href="#vtab6" data-toggle="tab">المراسلة</a></li>--}}
                <li><a href="<?php echo url('/') . "/" . Lang::getlocale() . "/" . "inbox"; ?>" >المراسلة</a></li>
            </ul>
        </div>
    </div>
</nav>
<script>
    function showNext()
    {
        $("#show").toggleClass('hideDiv');
    }
</script>