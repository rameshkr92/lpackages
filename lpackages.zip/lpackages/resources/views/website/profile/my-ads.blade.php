@extends('website.master')
@section('page_title')

@endsection
@section('content')



<div class="adslist">
    <div class="container">
        @include('website.blocks.page-message')
        <!--- Drop Box --->
        <form id="frm_filter_section" name="frm_filter_section" action="" method="get">
            <div class="form-group">
                    
                    <div class="col-md-3">
                        <select id="select111" class="form-control" name="section">
                            <option value="">-- حدد القسم--</option>
                            @if(count($sections)>0)
                                @foreach($sections as $sec)                          
                                    <option value="{{$sec->trans->section_id}}"  @if(isset($_GET['section']) && $_GET['section']!="")  @if($_GET['section'] == $sec->trans->section_id)  selected   @endif @endif>{{$sec->trans->name}}</option>
                               
                                    @endforeach
                            @endif
                        </select>
                    </div>
                    <button class="btn btn-raised btn-warning editbtn pull-left" type="submit">بحث</button> 
                </div>
            
        </form>    
        <table class="table" dir="rtl">
            <thead>
                <tr>
                    <th> الصوره</th>  <!-- IMage -->
                    <th> عنوان الاعلان</th> <!--- TITle -->
                    <th>الدولة / المنطقة</th>   <!---  Country / Region  -->
                    <th>تاريخ الاعلان</th>   <!-- Posted Date-->
                    <th> وقت الاعلان</th>  <!--- Time -->
                    <th>الحالة</th>
                    <th> تعديل الحذف </th> 

                </tr>
            </thead>
            <tbody>

                @if(isset($ads) && count($ads) > 0) 
                @foreach($ads as $ad)  
                <tr>
                    <td>

                        @if(isset($ad->media) && isset($ad->media->main_image) && isset($ad->media->main_image->styles['thumbnail']))
                        <a href="{{url('/')}}/{{Lang::getLocale()}}/section/{{$ad->section}}/{{$ad->id}}">      <img src="{{url('/')}}/{{ $ad->media->main_image->styles['thumbnail'] }}" style="max-width: 50%; border: 2px solid rgb(100, 100, 100);">
                        </a>     
                        @else
                        <img src="{{ asset('images/select_main_img.png') }}" style="max-width: 50%; border: 2px solid rgb(100, 100, 100);">
                        @endif          
                    </td>
                    <td>
                        <a href="{{url('/')}}/{{Lang::getLocale()}}/section/{{$ad->section}}/{{$ad->id}}">

                            @if(isset($ad->trans->name))   
                            {{  stripslashes($ad->trans->name)   }}

                            @else
                            لم يذكر
                            @endif
                        </a> </td>
                    <td>
                        @if(isset($ad->getCountry->trans->name) && isset($ad->getArea->trans->name))

                        {{  stripslashes($ad->getCountry->trans->name)   }}
                        /   {{  stripslashes($ad->getArea->trans->name)   }}

                        @else
                        لم يذكر

                        @endif
                    </td>
                    <td>    
                        @if(isset($ad->created_at))

                        {{    date('Y-m-d',strtotime($ad->created_at))  }}    

                        @endif
                    </td>
                    <td> 
                        @if(isset($ad->created_at))

                        {{    date('H:i:s',strtotime($ad->created_at))  }}    

                        @endif       
                    </td>

                    <td> 
                        @if(isset($ad->active))
                        @if($ad->active == 1)
                        {{    "مفعل"  }}    
                        @else
                        {{    "في إنتظار الإعتماد"    }}
                        @endif
                        @endif 
                    </td> 
                    <td> 

                        <a class="btn btn-primary btn-sm" href="{{url('/')}}/{{Lang::getLocale()}}/my-ads-edit/{{$ad->id}}">
                            تصحيح
                        </a>
                        <a class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد أنك تريد حذف؟')" href="{{url('/')}}/{{Lang::getLocale()}}/my-ads-delete/{{$ad->id}}">
                            حذف
                        </a>
                    </td>

                </tr>





                @endforeach



                @else

                <tr>
                    <td colspan="5" class="teimage">
                        <!--<img src="{{ asset('images/404.jpeg') }}">-->
                        <img src ="{{url('/')}}/uploads/fournotfour.jpeg">
                    </td>
                </tr>
                @endif
            </tbody>

        </table>

        @if(isset($ads))
        {{ $ads->links() }}
        @endif


    </div>
</div>
@endsection