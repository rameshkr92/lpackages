@extends('website.master')
@section('page_title')

@endsection
@section('content')


<div class="profile">
    <div class="container">
        @include('website.blocks.page-message')
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 sidemenuprofile">
            @include('website.profile.menu')
        </div>
        <div class="tab-content well profiledata col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <div role="tabpanel" class="tab-pane fade in active" id="vtab1">
                <a class="btn btn-raised btn-warning editbtn" href="<?php echo url('/') . "/" . Lang::getlocale() . "/" . "edit-profile"; ?>">تعديل الملف الشخصي</a> 
                <a class="btn btn-raised btn-warning editbtn" href="<?php echo url('/') . "/" . Lang::getlocale() . "/" . "change-phone"; ?>">تغيير رقم الهاتف
                </a>
                <h3> حسابى</h3>
                <div class="clearfix"></div>
                <br>
                <form action="#"  method="post">
                    <table dir="rtl" class="table table-striped table-hover col-lg-7">
                        <tbody>
                            <tr>
                                <td>اسم المستخدم</td>
                                <td colspan="2">{{ Auth::user()->name }}</td>
                            </tr>
                            <tr>
                                <td>البريد الالكترونى</td>
                                <td>

                                    {{ Auth::user()->email }}
                                    <input type='checkbox' name="change_email_show" id="change_email_show" title="على النقر هنا فإنه يظهر رقم الهاتف الخاص بك في صفحة الإعلان"   onclick="changeStatus('email',<?php echo Auth::user()->email_show; ?>)"  value="1" @if(Auth::user()->email_show == 1) checked @endif>
                                </td>
                                <td>
                                    {{-- <a href="#" data-toggle="modal" data-target="#myModalmailchange"> تغير البريد الالكترونى </a> --}}
                                </td>

                            </tr>
                            <tr>
                                <td>رقم الجوال</td>
                                <td>

                                    +{{ Auth::user()->phone }}
                                    <input type='checkbox' value="1"  id="change_phone_show" name="change_phone_show" title="انقر هنا لعرض بريدك الإلكتروني على صفحة الإعلان"  onclick="changeStatus('phone',<?php echo Auth::user()->phone_show; ?>)" @if(Auth::user()->phone_show == 1) checked @endif> 
                                </td>
                                <td>
                                    {{-- <a href="/{{ Lang::getLocale() }}/reset-mobile">تغير رقم الجوال</a> --}}
                                </td>
                            </tr>
                            @if(Auth::user()->country && Auth::user()->area)
                            <tr>
                                <td>الدوله</td>
                                <td>{{ Auth::user()->country->trans->name }}</td>  
                                <td> </td>                         
                            </tr>
                            <tr>
                                <td>المدينة</td>
                                <td>{{ Auth::user()->area->trans->name }}</td>
                                <td> </td>                           
                            </tr>

                            @endif
                            <tr>
                                <td>

                                    <!--- Controller data --->


                                    @if(isset($item->media) && isset($item->media->main_image) && isset($item->media->main_image->styles['thumbnail']))
                                    <img src="{{url('/')}}/{{ $item->media->main_image->styles['thumbnail'] }}" style="max-width: 100%; border: 2px solid rgb(204, 204, 204);">
                                    <input type="hidden" name="main_image_id" value="{{$item->media->main_image->id}}">
                                    @else
                                    <img src="<?php echo url('/'); ?>/website_assets/images/1.jpg" width="100" height="100" class="profilethum">
                                    @endif

                                </td>
                                <td colspan="2">
                                    {{-- <a href="#" class=" btn-demo" data-toggle="modal" data-target="#profileimgedit"> تغير الصوره الشخصية</a> --}}
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </form>
                <div class="modal fade" id="profileimgedit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog modal-sm" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="myModalLabel">غير الصوره الشخصية</h4> </div>
                            <div class="modal-body"> <img src="<?php echo url('/'); ?>/website_assets/images/1.jpg" width="200" height="200" />
                                <input type="file"> </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary btn-dialog" data-dismiss="modal">تغير الصوره</button>
                            </div>
                        </div>
                        <!-- modal-content -->
                    </div>
                    <!-- modal-dialog -->
                </div>
                <!-- modal -->

                <div class="modal fade" id="countryedit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog modal-sm" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="myModalLabel">  عديل بيانات الدولة والمدينة</h4> </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="s1">Your country</label>
                                    <select class="form-control">
                                        <option value="Apple fritter">Apple fritter</option>
                                        <option value="Croissant">Croissant</option>
                                        <option value="Donut">Donut</option>
                                        <option value="Financier">Financier</option>
                                        <option value="Jello">Jello</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="s1">Your city</label>
                                    <select class="form-control">
                                        <option value="Apple fritter">Apple fritter</option>
                                        <option value="Croissant">Croissant</option>
                                        <option value="Donut">Donut</option>
                                        <option value="Financier">Financier</option>
                                        <option value="Jello">Jello</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary btn-dialog" data-dismiss="modal">حفظ البيانات </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- modal -->
            </div>

            <div role="tabpanel" class="tab-pane fade" id="vtab2">
                <h3> اضافه اعلان </h3>
                <div class="clearfix"></div>
                <br>
                <div class="clearfix"></div>
                <div class="carform">
                    <form action="" method="">
                        <div class="form-group">
                            <label for="s1">اختر القسم</label>
                            <select id="dropDownMenuKategorie" class="form-control">
                                <option value="">سيارات</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                            </select>
                        </div>
                        <div class="form-group label-floating">
                            <label class="control-label">عنوان الاعلان</label>
                            <input type="text" class="form-control"> </div>
                        <div class="form-group carinput">
                            <label for="s1 ">الشركة</label>
                            <select class="form-control">
                                <option value=" ">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                            </select>
                        </div>
                        <div class="form-group carinput">
                            <label for="s1 "> النوع</label>
                            <select class="form-control">
                                <option value=" ">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                            </select>
                        </div>
                        <div class="form-group carinput">
                            <label for="s1">الموديل</label>
                            <select class="form-control">
                                <option value=" ">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="s1">الدولة</label>
                            <select class="form-control">
                                <option value=" fritter">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="s1">المنطقة </label>
                            <select class="form-control">
                                <option value=" ">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                                <option value="">قسم1</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="textArea" class="col-md-2 control-label">تفاصيل الاعلان</label>
                            <div class="col-md-10">
                                <textarea class="form-control" rows="3" id="textArea"></textarea> <span class="help-block">A longer block of help text that breaks onto a new line and may extend beyond one line.</span> </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="form-group label-floating">
                            <label class="control-label">اضافه وسيلة التواصل </label>
                            <input type="text" class="form-control"> </div>
                        <div class="form-group">
                            <input type="file" id="inputFile4">
                            <div class="input-group">
                                <input type="text" readonly="" class="form-control" placeholder="اختر صوره الاعلان"> <span class="input-group-btn input-group-sm">
                                    <button type="button" class="btn btn-fab btn-fab-mini">
                                        <i class="fa fa-paperclip" aria-hidden="true"></i>

                                    </button>
                                </span> </div>
                        </div>
                        <div class="form-group">
                            <input type="file" id="inputFile4" multiple="">
                            <div class="input-group">
                                <input type="text" readonly="" class="form-control" placeholder="اضافه صور اخرى  "> <span class="input-group-btn input-group-sm">
                                    <button type="button" class="btn btn-fab btn-fab-mini">
                                        <i class="fa fa-paperclip" aria-hidden="true"></i>
                                    </button>
                                </span> </div>
                        </div>
                        <div class="checkbox">
                            <label>
                                <input type="checkbox"> اتعهد أن أقوم بدفع عمولة الموقع بعد وضع الإعلان </label>
                        </div><a href="javascript:void(0)" class="btn btn-raised btn-primary">اضافه الاعلان</a>
                        <br> </form>
                </div>
            </div>


            <div role="tabpanel" class="tab-pane fade in  col-lg-12" id="vtab3">
                <h3>  اعلاناتى </h3>
                <a class="btn btn-raised btn-warning editbtn" href="<?php echo url('/') . "/" . Lang::getlocale() . "/" . "add-post"; ?>">  إضافة الإعلان  </a> 
                <a class="btn btn-raised btn-warning editbtn" href="<?php echo url('/') . "/" . Lang::getlocale() . "/" . "add-post-cars"; ?>"> 

                    إضافة إعلان في قسم السيارات
                </a>
                <div class="clearfix"></div>
                <br>
                <hr>
                <div class="adshistorycont">


                    @if(isset($ad) && count($ad) > 0)
                    @foreach($ad as $ads)
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class=" adshistory">

                            <a href="{{url('/')}}/{{Lang::getLocale()}}/my-ads-edit/{{$ads->id}}" class="edit-icon  fav-icon-active "> <i class="fa fa-pencil-square-o fa-2x" aria-hidden="true"></i></a>

                            <a href="{{url('/')}}/{{Lang::getLocale()}}/my-ads-profile-delete/{{$ads->id}}" class=" delete-icon fav-icon-active " onclick="return confirm('هل أنت متأكد أنك تريد حذف؟')"> 

                                <i class="fa fa-trash fa-2x" aria-hidden="true"></i></a>                                    <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">

                                @if(isset($ads->media) && isset($ads->media->main_image) && isset($ads->media->main_image->styles['thumbnail']))
                                <img src="{{url('/')}}/{{ $ads->media->main_image->styles['thumbnail'] }}" width="100" height="100">
                                </a>     
                                @else
                                <img src="{{ asset('images/select_main_img.png') }}" width="100" height="100"">
                                @endif 

                            </div>
                            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                                <ul>
                                    <li> 
                                        @if(isset($ads->trans->name))   
                                        {{  stripslashes($ads->trans->name)   }}

                                        @else
                                        لم يذكر
                                        @endif
                                    </li>
                                    <li>

                                        @if(isset($ads->getCountry->trans->name) && isset($ads->getArea->trans->name))

                                        {{  stripslashes($ads->getCountry->trans->name)   }}
                                        /   {{  stripslashes($ads->getArea->trans->name)   }}

                                        @else
                                        لم يذكر

                                        @endif    


                                        :  منطقة</li>

                                    <li>تاريخ الاضافه : 
                                        @if(isset($ads->created_at))

                                        {{    date('Y-m-d',strtotime($ads->created_at))  }}    

                                        @endif


                                    </li>
                                    <li>لتوقيت : 

                                        @if(isset($ads->created_at))

                                        {{    date('H:i:s A',strtotime($ads->created_at))  }}    

                                        @endif 

                                    </li>

                                    <li>الحالة :
                                        @if($ads->active == 1)
                                        {{    "مفعل"  }}    
                                        @else
                                        {{    "في إنتظار الإعتماد"    }}
                                        @endif
                                    </li>           

                                </ul>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>

                    @endforeach

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        @if(isset($ads_count) && count($ads_count) > 4)
                        <a href="{{url('/')}}/ar/my-ads" >
                            عرض المزيد
                        </a>
                        @endif
                    </div>   
                    @else              
                    <img src ="{{url('/')}}/uploads/fournotfour.jpeg">
                    @endif  

                </div>
            </div>
            <div role="tabpanel" class="tab-pane fade in  " id="vtab4">
                <h3>  تعليقات </h3>
                <div class="clearfix"></div>
                <br>
                <hr>
                <div class="adshistorycont">

                    @if(isset($user_comments) && count($user_comments)>0)
                    @foreach($user_comments as $key=>$value)
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class=" adshistory">

                            <input type='hidden' id='pass_user_comment_{{ $user_comments[$key]["id"]}}' value="{{ $user_comments[$key]["comment"]}}">
                            <a href="javascript:void(0);" class="edit-icon  fav-icon-active "> <i class="fa fa-pencil-square-o fa-2x" aria-hidden="true"  onclick="showModal({{ $user_comments[$key]["id"]  }})"></i></a>

                            <a href="{{url('/')}}/{{Lang::getLocale()}}/my-delete-comment/{{$user_comments[$key]["id"]}}" class=" delete-icon fav-icon-active " onclick="return confirm('هل أنت متأكد أنك تريد حذف؟')"> 


                                <i class="fa fa-trash fa-2x" aria-hidden="true"></i></a> 
                            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                                @if(isset($user_comments[$key]['thumbnail']))
                                <img src="{{url('/')}}/{{ $user_comments[$key]['thumbnail'] }}" width="100" height="100">
                                </a>     
                                @else
                                <img src="{{ asset('images/select_main_img.png') }}" width="100" height="100"">
                                @endif 



                            </div>

                            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                                <ul>
                                    <li>
                                        <a href="<?php echo url('/') ?>/ar/section/{{ $user_comments[$key]['section']  }}/{{ $user_comments[$key]['ad_id'] }}">

                                            <div id='user_replace_comment_{{ $user_comments[$key]["id"] }}'>
                                                @if(strlen($user_comments[$key]['comment'])>50)
                                                {{  substr($user_comments[$key]['comment'],0,50) }} ....

                                                @else
                                                {{  $user_comments[$key]['comment'] }}
                                                @endif
                                            </div>
                                        </a></li>

                                    <li>تاريخ الاضافه : 

                                        @if(isset($user_comments[$key]['created_at']))

                                        {{    date('Y-m-d',strtotime($user_comments[$key]['created_at']))  }}    

                                        @endif



                                    </li>
                                    <li>لتوقيت : 
                                        @if(isset($user_comments[$key]['created_at']))

                                        {{    date('H:i:s A',strtotime($user_comments[$key]['created_at']))  }}    

                                        @endif




                                    </li>
                                </ul>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    @endforeach

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        @if(isset($comment_count) && count($comment_count) > 4)
                        <a href="{{url('/')}}/ar/my-comments" >
                            عرض المزيد
                        </a>
                        @endif
                    </div>  

                    @else              
                    <img src ="{{url('/')}}/uploads/fournotfour.jpeg">
                    @endif

                    <div class="clearfix"></div>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane fade in  " id="vtab5">
                <h3>  المفضلة </h3>
                <div class="clearfix"></div>

                <div class="adshistorycont">

                    @if(isset($user_fav) && count($user_fav)>0)
                    @foreach($user_fav as $key=>$value)
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class=" adshistory">
                            <a href="#" class="fav-icon fav-icon-active"> <i class="fa fa-star fa-2x" aria-hidden="true"></i></a>
                            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
                                @if(isset($user_fav[$key]['thumbnail']))
                                <img src="{{url('/')}}/{{ $user_fav[$key]['thumbnail'] }}" width="100" height="100">
                                </a>     
                                @else
                                <img src="{{ asset('images/select_main_img.png') }}" width="100" height="100"">
                                @endif 



                            </div>

                            <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
                                <ul>
                                    <li>
                                        <a href="<?php echo url('/') ?>/ar/section/{{ $user_fav[$key]['section']  }}/{{ $user_fav[$key]['ad_id'] }}">

                                            {{  $user_fav[$key]['commentUser'] }}
                                        </a></li>

                                    <li>تاريخ الاضافه : 

                                        @if(isset($user_fav[$key]['created_at']))

                                        {{    date('Y-m-d',strtotime($user_fav[$key]['created_at']))  }}    

                                        @endif



                                    </li>
                                    <li>لتوقيت : 
                                        @if(isset($user_fav[$key]['created_at']))

                                        {{    date('H:i:s A',strtotime($user_fav[$key]['created_at']))  }}    

                                        @endif




                                    </li>
                                </ul>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    @endforeach

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        @if(isset($favourite_count) && count($favourite_count) > 4)
                        <a href="{{url('/')}}/ar/my-favourite" >
                            عرض المزيد
                        </a>
                        @endif
                    </div>   

                    @else              
                    <img src ="{{url('/')}}/uploads/fournotfour.jpeg">
                    @endif

                    <div class="clearfix"></div>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane fade in  " id="vtab6">
                <h3>  المراسلات </h3>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 min-messages">
                    <a href="#">
                        <div class="user-message"> <img src="<?php echo url('/'); ?>/website_assets/images/bg23.jpg" class="img-circle" width="50" height="50"> <span> محمود رضا</span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="user-message"> <img src="<?php echo url('/'); ?>/website_assets/images/bg23.jpg" class="img-circle" width="50" height="50"> <span> محمد احمد </span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="user-message read-message"> <img src="<?php echo url('/'); ?>/website_assets/images/bg23.jpg" class="img-circle" width="50" height="50"> <span> ابراهيم منصور</span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="user-message read-message"> <img src="<?php echo url('/'); ?>/website_assets/images/bg23.jpg" class="img-circle" width="50" height="50"> <span> عبد الله السيد</span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="user-message read-message"> <img src="<?php echo url('/'); ?>/website_assets/images/bg23.jpg" class="img-circle" width="50" height="50"> <span>محمود محمد</span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="user-message read-message"> <img src="<?php echo url('/'); ?>/website_assets/images/bg23.jpg" class="img-circle" width="50" height="50"> <span> احمد محمد</span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="user-message"> <img src="<?php echo url('/'); ?>/website_assets/images/bg23.jpg" class="img-circle" width="50" height="50"> <span> اسم مستخدم</span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="user-message"> <img src="<?php echo url('/'); ?>/website_assets/images/bg23.jpg" class="img-circle" width="50" height="50"> <span> اسم مستخدم</span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="user-message"> <img src="<?php echo url('/'); ?>/website_assets/images/bg23.jpg" class="img-circle" width="50" height="50"> <span> اسم مستخدم</span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                    <div class="message-content">
                        <div class="message-title">
                            <h5><i class="fa fa-user-o" aria-hidden="true"></i>
                                mahmoud reda</h5> </div>
                        <div>
                            <div class="message-data">
                                <div class="message-right">
                                    <p> هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا يوجد محتوى نصي، هنا يوجد محتوى نصي" فتجعلها تبدو </p>
                                </div>
                                <div class="message-left">
                                    <p> هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا يوجد محتوى نصي، هنا يوجد محتوى نصي" فتجعلها تبدو </p>
                                </div>
                                <div class="message-right">
                                    <p> هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا يوجد محتوى نصي، هنا يوجد محتوى نصي" فتجعلها تبدو </p>
                                </div>
                                <div class="message-left">
                                    <p> هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا يوجد محتوى نصي، هنا يوجد محتوى نصي" فتجعلها تبدو </p>
                                </div>
                                <div class="message-right">
                                    <p> هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا يوجد محتوى نصي، هنا يوجد محتوى نصي" فتجعلها تبدو </p>
                                </div>
                                <div class="message-left">
                                    <p> هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا يوجد محتوى نصي، هنا يوجد محتوى نصي" فتجعلها تبدو </p>
                                </div>
                            </div>
                            <div class="well well-lg">
                                <div class="media1">
                                    <div class="media-body">
                                        <div class="form-group" style="padding:12px;">
                                            <textarea class="form-control animated" placeholder="نص الرساله"></textarea>
                                            <button class="btn btn-info pull-right" style="margin-top:10px" type="button">ارسل رساله</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <form method="post">
            <div class="modal-content otherpro">
                <div class="modal-header addmodhe">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4> تعديل التعليق</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <textarea class="form-control"  placeholder=" " id="comment" id="report_content"></textarea>
                        <input type="hidden" name="comment_id" value="" id="comment_id">                  
                    </div>
                </div>
                <div class="modal-footer">
                    <ul>
                        <li>
                            <button type="button" class="btn btn-carsrace" onclick="saveComment()">   حفظ </button>
                        </li>
                        <li>
                            <button type="reset" class="btn btn-carsrace " data-dismiss="modal">   إلغاء  </button>
                        </li>
                    </ul>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
            function showModal(comment_id)
            {
                    var pass_comment = "#pass_user_comment_" + comment_id;
                    var comment = $(pass_comment).val();
                    $("#comment_id").val(comment_id);
                    $("#myModal").modal("show");
                    $("#comment").val(comment);
            }
</script>    
<script>
    function changeStatus(key = "", show)
    {

    if (key == "phone")
    {
    flag = 1;
            status = show;
    }
    if (key == "email")
    {
    flag = 0;
            status = show;
    }

    $.ajax({
    url: javascript_site_path + "ar/change-show-status", //The url where the server req would we made.
            type: "POST", //The type which you want to use: GET/POST
            data: {
            content: flag,
                    status: status,
                    key: key,
            }, //The variable{"label":"' . $arr_cities[$i]['city_name'] . '", "value":"' . $arr_cities[$i]['city_name'] . '","id":"' . $arr_cities[$i]['city_id'] . '"},'s which are going. //Return data type (what we expect).
            //This is the function which will be called if ajax call is successful.
            success: function(data) {

            //data is the html of the page where the request is made.
            if (data == 1)
            {
            alert("تم التغيير بنجاح");
                    window.location.href = window.location.href;
            }
            }
    });
    }


</script>
<script>
    function saveComment()
    {
            var comment = $("#comment").val();
            var comment_id = $("#comment_id").val();
            if (comment != "" && comment_id != "")
    {
    $.ajax({
    url: javascript_site_path + "ar/update-comment", //The url where the server req would we made.
            type: "POST", //The type which you want to use: GET/POST
            data: {
            comment_id: comment_id,
                    comment: comment,
            }, //The variable{"label":"' . $arr_cities[$i]['city_name'] . '", "value":"' . $arr_cities[$i]['city_name'] . '","id":"' . $arr_cities[$i]['city_id'] . '"},'s which are going. //Return data type (what we expect).
            //This is the function which will be called if ajax call is successful.
            success: function(data) {

            //data is the html of the page where the request is made.
            if (data == 1)
            {
            alert("تم تحديث التعليق بنجاح");
                    $("#myModal").modal("hide");
                    if(comment.length > 50)
                    {
                     var  new_comment = comment.substr(0, 50) + "...."; 
                    }else{
                      var  new_comment =   comment;
                    }
                    var replace_comment = "#user_replace_comment_" + comment_id;
                    $(replace_comment).html(new_comment);
                    
                    var pass_comment = "#pass_user_comment_" + comment_id;
                    $(pass_comment).val(comment);
            } else{
            alert("هناك بعض المشاكل في فونتيونينغ");
            }
            }
    });
    } else{

    alert("الرجاء إدخال شيء");
    }


    }
</script>   
@endsection