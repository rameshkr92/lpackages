@extends('website.master')
@section('page_title')
@endsection
@section('content')
<div class="profilevisit">
    <div class="container">
        <main>
            <div class="profile">
                <div class="profile-header">
             
                    
                <img src="{{url('/')}}/website_assets/images/bg23.jpg" alt="" />
                </div>
                <div class="profile-content">
                           @if(isset($user->media) && isset($user->media->main_image) && isset($user->media->main_image->styles['thumbnail']))
                                    <img src="{{url('/')}}/{{ $user->media->main_image->styles['thumbnail'] }}">
                                   
                                    @else
                                    
                                    <img src="{{url('/')}}/website_assets/images/1.jpg" alt="Portret of Sara Robertson" />
                                    @endif
                    
                    <h1>
                        @if(isset($user->name))
                        {{ $user->name }}
                        @endif
                    </h1>  <!-- User Name -->

                    <p>
                        @if(isset($user->country->trans->name))
                        {{ $user->country->trans->name }}
                        @endif
                    </p> <!-- user country --->
                    <p>
                        @if(isset($user->area->trans->name))
                        {{ $user->area->trans->name }}
                        @endif

                    </p> <!-- user area --->
                    <p>عدد المشاركات :
                        
                        @if(isset($ads_count))
                        {{  $ads_count }}
                        @else
                        {{  "0" }}
                        @endif
                        مشاركه</p> <!--  Total Profile View -->
                    <p>    
                     @if(($user->phone_show == 1))
                        {{ $user->phone }}
                        @endif  
                    </p> <!--  User Number -->
                    <p>    
                    @if(($user->email_show == 1))
                        {{ $user->email }}
                        @endif      
                    </p> <!--  User Email -->


<!--                    <a href="#contactuser">
                        <button class="contactuserbtn" type="button">راسل العضو</button>
                    </a>-->
                </div>
            </div>

        </main>
    </div>
    
    <div class="latestads">
    <div class="container">
    	<div class="latestads-main  clearfix">
        <div class="col-md-12 titlealign">
            <h3>
          اعلانات العضو   
        </h3> </div>

         <div class="clearfix"></div>
        
         
         
        <div class="owl-carousel">
            
            
            @if(isset($latest_ads) && count($latest_ads) > 0)
            
            @foreach($latest_ads as $ad)
            
            <div>
                <div class="col-item">
                	<div class="photo-main">
                    <div class="photo"> 
                        @if(isset($ad->media) && isset($ad->media->main_image) && isset($ad->media->main_image->styles['thumbnail'])) 
                        
                    
                      
                        
                        <a href="{{url('/')}}/{{Lang::getLocale()}}/section/{{$ad->section}}/{{$ad->id}}">      <img src="{{url('/')}}/{{ $ad->media->main_image->styles['thumbnail'] }}" width="300" height="200">
                                   </a> 
                        @else
                        <img src ="{{url('/')}}/uploads/fournotfour.jpeg">
                        @endif 
                        
                    </div>
                    
                    
                    <div class="info">
                        <div class="row">
                            <div class="price col-md-12"> 
                                
                               
                                <a href="{{url('/')}}/{{Lang::getLocale()}}/section/{{$ad->section}}/{{$ad->id}}"><h5>
                                     @if(isset($ad->trans->name)) {{ $ad->trans->name }} @endif
                            </h5></a> </div>
                        </div>
                    </div>
                    </div>
                </div>
                
                
               
                
            </div>
            
          
            @endforeach
            @else
            
             <img src ="{{url('/')}}/uploads/fournotfour.jpeg">
            
            
           @endif
          
            
            
        </div>
        
       </div> 
    </div>
</div>
<!--    <div class="userads">
        <div class="container">
            <div class="row">
                <div class="col-md-12 titlealign">
                    <h3>
                        اعلانات العضو   
                    </h3> </div>

            </div>

                        <div class="col-md-12 titlealign">
                            <h3>
                       راسل العضو   
                    </h3> </div>
                        <div id="contactuser" class="status-upload editmargin">
                            <form>
                                <textarea placeholder="send message here"></textarea>
                                <button type="submit" class="btn btn-success green"><i class="fa fa-commenting"></i>ارسل رساله</button>
                            </form>
                        </div>
        </div>
    </div>-->
</div>
@endsection