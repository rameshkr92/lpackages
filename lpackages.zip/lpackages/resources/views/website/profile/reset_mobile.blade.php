@extends('website.master')
@section('page_title')

@endsection
@section('content')
<div class="well login-box col-lg06">
    <form action="">
        <div class="form-group label-floating">
            <label class="control-label" for="focusedInput2">رقم الجوال</label>
            <input class="form-control" id="focusedInput2" type="text">
            <p class="help-block"> برجاء ادخال رقم الجوال </p>
        </div>
        <input class="btn btn-success btn-login-submit" value="تاكيد" id="codebtn" />
        <div class="codeinput ">
            <div class="form-group label-floating">
                <label class="control-label" for="focusedInput2">الكود</label>
                <input class="form-control" id="focusedInput2" type="text">
                <p class="help-block">برجاء ادخال رقم الكود </p>
            </div>
            <input class="btn btn-success btn-login-submit" value="تفعيل" /> </div>
            <div class="checkbox">
                            <label>
                                <input type="checkbox"> اظهار رقم الجوال </label>
                        </div>
    </form>
</div>
@endsection