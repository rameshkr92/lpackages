<footer class="footer-container">
    <div class="container">
        <div class="foot-blk clearfix">
            <div class="foot-links pull-left">
                <ul class="clearfix">
                    <li>
                        <a href="{{ action('CmsController@showPage', 'about-us') }}">About Us</a>
                    </li>
                    <li>
                        <a href="{{url('/').'/'.Lang::getLocale()}}/contact-us">Contact us </a>
                    </li>
                    <li>
                        <a href="{{ action('CmsController@showPage', 'terms') }}">Terms & Conditions </a>
                    </li>
                    <li>
                        <a href="{{ action('CmsController@showPage', 'privacy-policy') }}">Privacy policy  </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)">FAQs </a>
                    </li>
                </ul>
            </div>
            <div class="foot-soci pull-right">
                <ul class="clearfix">
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-facebook"></i> </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-google-plus"></i> </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)"><i class="fa fa-instagram"></i> </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<script src="{{ asset('website_assets/js/jquery.validate.js') }}" type="text/javascript"></script>
<script src="{{ asset('website_assets/js/customize/user.js') }}" type="text/javascript"></script>
<!------------------ Login Modal ------------------>
<div class="cust-modal">
    <div class="modal fade" id="myModallogin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fa fa-remove"></i></span></button>
                <div class="modal-body">
                    <div class="sign-form">
                        <div class="social-sin relative ">
                            <ul>
                                <li><a href="{{ url('/auth/facebook') }}"><i class="fa fa-facebook"></i></a></li>
                            </ul>
                        </div>
                        <div class="sign-head text-center">
                            <h4>Sign in your account</h4>
                            <p>Don’t have an Account? <a href="javascript:void(0)" data-toggle="modal" data-target="#myModalRegister" data-dismiss="modal">Click here</a> to register</p>
                        </div>
                        @include('website.blocks.page-message')
                        <form name="frm_login" id="frm_login" action="{{ action('WebsiteController@postLogin') }}" method="post" autocomplete="off">
                            <div class="sign-body">
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative">
                                            <input required class="form-control" placeholder="Email" id="user_email" name="user_email" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative">
                                            <input class="form-control" placeholder="Password" name="user_password" id="user_password" type="password">
                                            <div for="user_password" generated="true" class="text-danger" style="display: none;"></div>
                                            <div class="row">

                                                <div class="col-xs-6">
                                                    <div class="forg-paswd text-left">
                                                        <label><input type="checkbox" name="remember" value="1"><span>Remember me</span></label></div>
                                                </div>
                                                <div class="col-xs-6">
                                                    <div class="forg-paswd text-right">
                                                        <a href="javascript:void(0)" data-toggle="modal" data-target="#forgotPasswordModal" data-dismiss="modal" >Forget Password</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sign-terms sign-head text-center " >
                                            <p>By logging in you agree to our <a href="">Terms &amp; Conditions</a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-btn text-center">
                                            <button class="btn cust-btn animate text-uppercase" type="submit">Sign In</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!------------------ Forgot Password ------------------>
<div class="cust-modal">
    <div class="modal fade" id="forgotPasswordModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"><i class="fa fa-remove"></i></span>
                </button>
                <div class="modal-body">
                    <div class="sign-form">
                        <div class="social-sin relative ">
                            <ul>
                                <li><a href="javascript:void(0)"><i class="fa fa-send"></i></a></li>
                            </ul>
                        </div>
                        <div class="sign-head text-center">
                            <h4>{{trans('project.forgot_password')}}</h4>
                            <p>{{trans('project.forgot_password_sub_heading')}}</p>
                        </div>
                        @include('website.blocks.page-message')
                        <form name="frm_forgot_password" id="frm_forgot_password" action="{{ action('WebsiteController@forgotPasswordUserValidation') }}" method="post" autocomplete="off">
                            <div class="sign-body">
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative">
                                            <input required class="form-control" placeholder="Email" id="reset_email" name="reset_email" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sign-terms sign-head text-center " >
                                            <p>{{trans('project.already_have_an_account')}} <a href="javascript:void(0)" data-toggle="modal" data-target="#myModallogin" data-dismiss="modal">{{trans('project.click_here')}}</a> {{trans('project.to_login')}}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-btn text-center">
                                            <button class="btn cust-btn animate text-uppercase" type="submit">Send <i class="fa fa-send"></i> </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!------------------ register Modal ------------------>
<script src="{{ asset('website_assets/intl-telephone/js/intlTelInput.js') }}" type="text/javascript"></script>
<?php
$countries = \Innoflame\Countries\Models\Country::where(array('active'=> 1))->get();
$all_iso = [];
if(count($countries)){
    foreach ($countries as $cntry => $country){
//            echo $country->trans['iso_code'];
        $all_iso[] = strtolower($country->trans['iso_code']);
    }
    $isoCodes = json_encode($all_iso);
}else{
    $isoCodes = [];
}
?>
<script type="text/javascript">
    $(function() {
        $('#frm_registration')
            .find('[name="phone"]')
            .intlTelInput({
                preferredCountries: ['ae', 'in', 'us'],
                autoPlaceholder: true,
                onlyCountries: {!! $isoCodes !!},
                utilsScript: '{{ asset('website_assets/intl-telephone/js/utils.js') }}'
            });
        $('#frm_registration')
            .find('[name="phone"]').on("countrychange", function (e, countryData) {
            $("#phone_country_code").val(countryData.iso2);
        });
    });
</script>
<div class="cust-modal">
    <div class="modal fade" id="myModalRegister" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fa fa-remove"></i></span></button>
                <div class="modal-body">
                    <div class="sign-form">
                        <div class="social-sin relative ">
                            <ul>
                                <li><a href="{{ url('/auth/facebook') }}"><i class="fa fa-facebook"></i></a></li>
                            </ul>
                        </div>
                        <div class="sign-head text-center">
                            <h4>{{trans('project.create_your_account')}}</h4>
                            <p>{{trans('project.already_have_an_account')}} <a href="javascript:void(0)" data-toggle="modal" data-target="#myModallogin" data-dismiss="modal">{{trans('project.click_here')}}</a> {{trans('project.to_login')}}</p>
                        </div>
                        <form name="frm_registration" id="frm_registration" action="{{ action('WebsiteController@postRegister') }}" method="post" >
                            <div class="sign-body">
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative">
                                            <input required class="form-control" placeholder="Name" id="name" name="name" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative">
                                            <input required class="form-control" placeholder="Email" id="email" name="email" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative">
                                            <input type="tel" class="form-control" id="phone" name="phone"/>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="iso2" id="phone_country_code" value=""/>

                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative cust-select">
                                            <select id="reg_country" name="country" class="form-control">
                                                <option value="">- {{trans('Core::operations.select').' '.ucfirst(trans('Countries::countries.country'))}} -</option>
                                                @if(isset($countries) && $countries->count())
                                                    @foreach($countries as $country)
                                                        <option value="{{ $country->id }}" @if($country->id == old('country',$country->id)) selected @endif>{{ ucwords(strtolower($country->trans->name)) }}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative cust-select">
                                            <select id="reg_area" name="area" class="form-control">
                                                <option value="">- {{trans('Core::operations.select').' '.ucfirst(trans('Countries::countries.area'))}} -</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative">
                                            <input type="password" class="form-control" placeholder="Password" id="password" name="password"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-inp relative">
                                            <input type="password" class="form-control" placeholder="Confirm Password" id="password_confirmation" name="password_confirmation"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sign-terms sign-head text-center " >
                                            <p>By logging in you agree to our <a href="">Terms &amp; Conditions</a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <div class="sin-btn text-center">
                                            <button class="btn cust-btn animate text-uppercase" type="submit">Register</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        // Load country areas
        $('#reg_country').off().on("change", function() {
            loadRegCountryAreas(this.value);
        });
    });
    function loadRegCountryAreas(countryId) {
        $("#reg_area option").remove();
        $.get("{{url('/')}}/{{ Lang::getLocale() }}/country-areas/" + countryId, function(data) {
            $("#reg_area").append($("<option></option>").attr("value", "").text("-- {{trans('Core::operations.select'). " ". ucfirst(trans('Countries::countries.area'))}} --"));
            for (var i = 0; i < data.areas.length; i++) {
                $("#reg_area").append($("<option></option>").attr("value", data.areas[i].id).text(data.areas[i].trans.name));
                var oldArea = "{{ old('area') }}";
                if (oldArea != '') {
                    $('#reg_area').val(oldArea);
                }
            }
        });
    }
</script>