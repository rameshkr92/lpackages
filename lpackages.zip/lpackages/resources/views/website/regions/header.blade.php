<input type="hidden" id="base_path" value="{{url('/')}}/" />
{{--@if(Auth::guest())--}}

<div id="container-floating">
    <?php
    $url = Request::url();
    if(Request::segment(1) == ""){
        $ar_url = $url.'/ar';
        $en_url = $url.'/en';
    }else{
        $ar_url = str_replace('/en/','/ar/',$url);
        $en_url = str_replace('/ar/','/en/',$url);
    }
    ?>
    <div class="nd3 nds" data-toggle="tooltip" data-placement="left" data-original-title="Reminder">
        <a href="{{$ar_url}}">
            <p class="letter">ع</p>
        </a>
    </div>
    <div class="nd1 nds" data-toggle="tooltip" data-placement="left" data-original-title="Edoardo@live.it">
        <a href="{{$en_url}}">
            <p class="letter">E</p>
        </a>
    </div>
    <div id="floating-button" data-toggle="tooltip" data-placement="left" data-original-title="Create" onClick="newmail()">
        <p class="plus"><i class="fa fa-language " aria-hidden="true"></i></p>
    </div>
</div>
{{--@if(Request::segment(2) == "user" && (Request::segment(4) != "create" || Request::segment(4) != "edit"))--}}
@if(Request::segment(2) == "user" && Request::segment(4) != "create")
    <div class="db-header clearfix">
        <div class="db-logo pull-left">
            <a href="{{url('/'.Lang::getLocale().'/home')}}">
                <img src="{{url('/')}}/website_assets/images/Logo.png">
            </a>
        </div>
        <div class="user-logout pull-right">
            <div class="media-left">
                {{--<span><img src="{{url('/')}}/website_assets/images/user.png"></span>--}}
                <span>
                    @php
                        $userAccount = \Innoflame\Users\Models\User::findOrFail(Auth::user()->id);
                    @endphp
                    @if(isset($userAccount->media) && isset($userAccount->media->main_image) && isset($userAccount->media->main_image->styles['thumbnail']))
                        <img src="{{url('/')}}/{{ $userAccount->media->main_image->styles['thumbnail'] }}" >
                        <input type="hidden" name="main_image_id" value="{{$userAccount->media->main_image->id}}">
                    @else
                        <img src="{{ asset('images/select_main_img.png') }}" style="max-width: 100%; border: 2px solid rgb(204, 204, 204);">
                    @endif
                </span>
            </div>
            <div class="media-body">
                <span>{{Auth::user()->name}}</span>
                <a href="{{ action('WebsiteController@logout') }}"><i class="fa fa-sign-out"></i>LogOut</a>

            </div>
        </div>
        <div class="db-add-store">
            <a href="{{ action('StoreController@addStore') }}">
                <i class="fa fa-address-card" aria-hidden="true"></i>
                <span>Add store</span>
            </a>
        </div>
    </div>
@endif
<link rel="stylesheet" href="{{ asset('website_assets/intl-telephone/css/intlTelInput.css') }}">
