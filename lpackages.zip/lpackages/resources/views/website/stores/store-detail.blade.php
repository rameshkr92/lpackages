@extends('website.master')
@section('content')
    <div class="content">
        @include('website.home.blocks.top-head')
        @include('website.regions.header')
        <hr class="hredit">
        <div class="place-page">
            <div class="">
                <section style="background:#efefe9;">
                    <div class="container">
                        <div class="board">
                            <div class="board-inner">
                                <ul class="nav nav-tabs" id="myTab">
                                    <div class="liner"></div>
                                    <li class="active">
                                        <a href="#home" data-toggle="tab" title="info">
                                            <span class="round-tabs one"><i class="glyphicon glyphicon-home"></i></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#profile" data-toggle="tab" title="location">
                                            <span class="round-tabs two"><i class="fa fa-map-marker "></i></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#messages" data-toggle="tab" title="Gallery">
                                            <span class="round-tabs three"><i class="fa fa-picture-o"></i></span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="home">
                                    <div class="english-title relative">
                                        <h1>{{$item->trans->name}}</h1>
                                        <div class="rati-blk">
                                            {{--                                            {{ dd($is_rated->trans) }}--}}
                                            @if(isset($is_rated))
                                                <a class="disabled" onclick="return checkIfRated();" href="javascript:void(0);">Write a Review</a>
                                            @else
                                                <a data-toggle="modal" href="#rating-modal">Write a Review</a>
                                            @endif
                                            <span id="store_avg_rating"></span>
                                            {{--<span><i class="fa fa-star"></i></span>--}}
                                            {{--<span><i class="fa fa-star"></i></span>--}}
                                            {{--<span><i class="fa fa-star"></i></span>--}}
                                            {{--<span><i class="fa fa-star-half-o"></i></span>--}}
                                            {{--<span><i class="fa fa-star-o"></i></span>--}}
                                        </div>
                                    </div>
                                    {{--{{ dd($item->trans) }}--}}
                                    <div class="place-data">
                                        <ul>
                                            <li> <i class="fa fa-globe" aria-hidden="true"></i>{{ $item->trans->location }}</li>
                                            <li> <i class="fa fa-eye" aria-hidden="true"></i>{{ $item->view_count }} view(s)</li>
                                            <li> <i class="fa fa-search" aria-hidden="true"></i>{{ $item->search_count }} search</li>
                                        </ul>
                                    </div>
                                    <div class="smicons">
                                        <ul class="clearfix">
                                            @if(isset($item))
                                            <li>
                                                <a href="{{ $item->trans->instagram_media }}" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                            </li>
                                            <li>
                                                <a href="{{ $item->trans->facebook_media }}" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
                                            </li>
                                            <li>
                                                <a href="{{ $item->trans->twitter_media }}" target="_blank"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
                                            </li>
                                            <li>
                                                <a href="{{ $item->trans->googleplus_media }}" target="_blank"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a>
                                            </li>
                                            @endif
                                        </ul>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="profile">
                                    {{--<iframe src="http://maps.google.com/maps?q=12.927923,77.627108&z=15&output=embed" width="100%" height="500"></iframe>--}}
                                    <iframe src="http://maps.google.com/maps?q={{ $item->trans->store_lat }},{{ $item->trans->store_lng }}&z=15&output=embed" width="100%" height="500"></iframe>
                                </div>
                                <div class="tab-pane fade" id="messages">
                                    <div class="images-gallery">
                                        <h3>images gallery</h3>
                                        <hr>
                                        <div class="demo-gallery">
                                            <ul id="lightgallery" class="list-unstyled row">
                                                @if (isset($gallery_images) && count($gallery_images) > 0)
                                                    @foreach($gallery_images as $imgKey=>$images)
                                                        <li class="col-xs-6 col-sm-4 col-md-3 img-gallery" data-responsive="{{url('/')}}/{{ $images['file'] }} 375, {{url('/')}}/{{ $images['file'] }} 480, {{url('/')}}/{{ $images['file'] }} 800" data-src="{{url('/')}}/{{ $images['file'] }}" data-sub-html="<h4>Bowness Bay</h4><p>A beautiful Sunrise this morning taken En-route to Keswick not one as planned but I'm extremely happy I was passing the right place at the right time....</p>">
                                                            <a href=""> <img class="img-responsive" src="{{url('/')}}/{{ $images['file'] }}"> </a>
                                                        </li>
                                                    @endforeach
                                                @endif
                                            </ul>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                    <hr>
                                    {{--<div class="images-gallery">--}}
                                        {{--<h3>Vedio gallery</h3>--}}
                                        {{--<hr>--}}
                                        {{--<!-- Hidden video div -->--}}
                                        {{--<div style="display:none;" id="video1">--}}
                                            {{--<video class="lg-video-object lg-html5" controls preload="none">--}}
                                                {{--<source src="vedio/videoplayback (1) (online-video-cutter.com).mp4" type="video/mp4"> Your browser does not support HTML5 video. </video>--}}
                                        {{--</div>--}}
                                        {{--<div style="display:none;" id="video2">--}}
                                            {{--<video class="lg-video-object lg-html5" controls preload="none">--}}
                                                {{--<source src="vedio/videoplayback (1) (online-video-cutter.com).mp4" type="video/mp4"> Your browser does not support HTML5 video. </video>--}}
                                        {{--</div>--}}
                                        {{--<!-- data-src should not be provided when you use html5 videos -->--}}
                                        {{--<div class="html5-videos-blk">--}}
                                            {{--<ul id="html5-videos" class="clearfix">--}}
                                                {{--<li class="" data-poster="img/image-3.jpg" data-sub-html="video caption1" data-html="#video1"> <img src="img/image-3.jpg" width="100%" height="150" /> </li>--}}
                                                {{--<li data-poster="img/image-3.jpg" data-sub-html="video caption2" data-html="#video2" class=""> <img src="img/image-3.jpg" width="100%" height="150" /> </li>--}}
                                            {{--</ul>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
@endsection
@section('footer')
    <link rel="stylesheet" href="{{ asset('website_assets/raty-master/lib/jquery.raty.css') }}">
    <!-- Bootstrap trigger to open modal -->
    <div class="modal fade" id="rating-modal" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close"
                            data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">Close</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel">
                        Write your review
                    </h4>
                </div>
                <form role="form" id="frm_store_rating" action="{{ action('StoreController@rateNow') }}" method="post">
                    <input type="hidden" name="store_id" value="{{ $item->trans->store_id }}"/>
                    <!-- Modal Body -->
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="store_comment">Comment / Review</label>
                            <textarea class="form-control" name="store_comment" id="store_comment" placeholder="Your comment goes here.."></textarea>
                        </div>
                        <div class="form-group">
                            <label for="store_rating">Your Rating</label>
                            <div id="store_rating"></div>
                        </div>
                    </div>
                    <!-- Modal Footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" class="btn btn-success">
                            Rate Now
                        </button>
                    </div>
                    <input name="language[ar]" value="ar" type="hidden"/>
                    <input name="language[en]" value="en" type="hidden"/>
                </form>
            </div>
        </div>
    </div>
    {{--{{dd($item)}}--}}
    <script src="{{ asset('website_assets/raty-master/lib/jquery.raty.js') }}" type="text/javascript"></script>
    <?php
    if(isset($item) && $item->rating_count > 0){
        $avg_rating = $item->avg_rating / $item->rating_count;
    }else{
        $avg_rating = $item->avg_rating;
    }
    ?>
    <script type="text/javascript">
        $('#store_avg_rating').raty({
            readOnly: true,
            start: "{{isset($avg_rating) ? $avg_rating : "0"}}",
            score: "{{isset($avg_rating) ? $avg_rating : "0"}}",
            path: "{{ url('/') }}/website_assets/raty-master/lib/images",
            half: true,
        });
        $('#store_rating').raty({
            scoreName: 'rating_val',
            path: "{{ url('/') }}/website_assets/raty-master/lib/images",
            half: true,
            cancel      : true,
            cancelPlace : 'right'
        });
        function checkIfRated() {
            var isLoggedIn = "{{ isset($userData) ? $userData->id : "" }}";
            if(isLoggedIn !='') {
                alert('You have already rated this store.');
            }
            else{
                alert('Please login to rate this store.');
            }
        }
    </script>
    <script src="{{ asset('website_assets/js/jquery.validate.js') }}" type="text/javascript"></script>
    <script src="{{ asset('website_assets/js/customize/rating.js') }}" type="text/javascript"></script>
@stop