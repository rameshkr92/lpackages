<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | This file is where you may define all of the routes that are handled
  | by your application. Just tell Laravel the URIs it should respond
  | to using a Closure or controller method. Build something great!
  |
 */
// Public routes
Route::get('/', 'WebsiteController@home');
Route::post('get-selected-cities', 'WebsiteController@getSelectedCities');

# Locale
$locale = \Request::segment(1);
Route::group(['prefix' => $locale], function() {
    Route::get('/home', 'WebsiteController@index');
    // Auth
    Route::get('login', 'WebsiteController@login');
    Route::post('login', 'WebsiteController@postLogin');

    Route::get('register', 'WebsiteController@register');
    Route::post('register', 'WebsiteController@postRegister');
    Route::get('country-areas/{countryId}', 'WebsiteController@countryAreas');
    // Sms confirmation
    Route::get('confirm-account/{userId}/{userPhone}/{confirmationType}', 'WebsiteController@confirmCode');
    Route::post('confirm-account/{userId}', 'WebsiteController@postConfirmCode');

    //email verification
    Route::get('verify-user-email/{id}', 'WebsiteController@verifyUserEmail');

    // Forgot password
    Route::get('forgot-password', 'WebsiteController@forgotPassword');
    Route::post('forgot-password', 'WebsiteController@forgotPasswordUserValidation');
    Route::post('retrieve-password-by-phone/{userId}', 'WebsiteController@postConfirmCodeRetrievePassword');
    Route::get('reset-password/{userId}/{confirmationCode}', 'WebsiteController@resetPassword');
    Route::post('reset-password/{userId}', 'WebsiteController@postResetPassword');

    Route::get('email-change/{userId}/{confirmationCode}', 'WebsiteController@emailChange');

    Route::get('change-phone', 'WebsiteController@changePhone');

    Route::post('change-phone-post', 'WebsiteController@changePhonePost');

    Route::get('old-phone-confirm', 'WebsiteController@oldPhoneConfirm');
    Route::post('old-phone-confirm-post', 'WebsiteController@oldPhoneConfirmPost');

    Route::get('new-change-phone', 'WebsiteController@newchangePhone');
    Route::post('new-change-phone-post', 'WebsiteController@newChangePhonePost');

    Route::get('new-phone-confirm', 'WebsiteController@newOtpConfirm');

    Route::post('new-phone-confirm-post', 'WebsiteController@newPhoneConfirmPost');

    // Pages
    Route::get('pages/{pageId}', 'CmsController@showPage');

    // Contact-us
    Route::get('contact-us', 'WebsiteController@createContact');
    Route::post('contact-us', 'WebsiteController@createContact');

    // public profile
    Route::get('profile/{userName}', 'WebsiteController@publicProfile');

    Route::post('change-show-status', 'WebsiteController@changeShowStatus');

    Route::post('delete-gallery-images', 'WebsiteController@deleteGalleryImages');

    Route::get('/search-result', 'SearchController@searchResult');
    Route::get('/search-result/{id}/view', 'SearchController@storeDetail');
    //logout rhe user
    Route::get('/logout', 'WebsiteController@logout');
});

// Registerd user routes
Route::group(['prefix' => $locale], function() {
    // User profile
    Route::get('user', 'WebsiteController@dashboard');
    Route::get('user/profile', 'WebsiteController@profile');
//    Route::get('user/edit-profile', 'WebsiteController@editProfile');
    Route::post('user/edit-profile', 'WebsiteController@updateProfile');

    Route::post('user/post-edit', 'WebsiteController@postEdit');
    Route::get('user/reset-mobile', 'WebsiteController@resetMobile');
});
Route::get('check-email-vailability', 'WebsiteController@checkEmailAvailability');

// OAuth Routes
Route::get('auth/{provider}', 'WebsiteController@redirectToProvider');
Route::get('auth/{provider}/callback', 'WebsiteController@handleProviderCallback');

// Store routes start here
Route::group(['prefix' => $locale], function() {

    Route::GET('user/stores', 'StoreController@index');
    Route::GET('user/stores/create', 'StoreController@addStore');
    Route::POST('user/stores', 'StoreController@saveStore');
    Route::GET('user/stores/{id}/edit', 'StoreController@edit');
    Route::PATCH('user/stores/{id}', 'StoreController@update');
    //view
    Route::GET('user/stores/{id}/view', 'StoreController@view');

    Route::GET('user/stores/{id}/view', 'StoreController@view');
    Route::POST('user/stores/bulk-operations', 'StoreController@bulkOperations');
    //rate a star
    Route::POST('user/stores/ratenow', 'StoreController@rateNow');

    //api
//    Route::GET('user/stores', 'StoreController@index');
    Route::GET('user/stores/instagram', 'StoreController@getInstagramData');

});
// Store routes end here